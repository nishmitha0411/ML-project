// Color analysis engine: undertone, depth, season classification
// Undertone classification is powered by an in-browser Random Forest
// trained on 8 features (R, G, B, R-G, R-B, G-B, B-R, ITA).
import { ALL_SEASONS, type Season } from "./seasons";
import { detectAllFaces, detectPrimaryFace, assessFace, type FaceBox } from "./faceDetect";
import { predictUndertone } from "./undertoneModel";

export interface RGB { r: number; g: number; b: number; }

export interface AnalysisResult {
  season: Season;
  undertone: "Warm" | "Cool" | "Neutral";
  depth: "Light" | "Medium" | "Deep";
  confidence: number; // 0-100
  harmony: number;    // 0-100
  skin: RGB;
  eye?: RGB;
  hair?: RGB;
  probabilities: { season: Season; pct: number }[];
}

export class NoFaceError extends Error {
  constructor(msg = "No human face detected. Please upload a clear, well-lit photo of a face.") {
    super(msg); this.name = "NoFaceError";
  }
}
export class MultipleFacesError extends Error {
  faces: FaceBox[];
  imgW: number;
  imgH: number;
  previewUrl: string;
  constructor(faces: FaceBox[], imgW: number, imgH: number, previewUrl: string) {
    super("Multiple faces detected — please pick the right one.");
    this.name = "MultipleFacesError";
    this.faces = faces; this.imgW = imgW; this.imgH = imgH; this.previewUrl = previewUrl;
  }
}

export function hexToRgb(hex: string): RGB {
  const h = hex.replace("#", "");
  return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
}

export function rgbToHex({ r, g, b }: RGB): string {
  const t = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
  return `#${t(r)}${t(g)}${t(b)}`;
}

export function averageRgb(list: RGB[]): RGB {
  const n = list.length || 1;
  const s = list.reduce((a, c) => ({ r: a.r + c.r, g: a.g + c.g, b: a.b + c.b }), { r: 0, g: 0, b: 0 });
  return { r: s.r / n, g: s.g / n, b: s.b / n };
}

export function classifyUndertone(skin: RGB): "Warm" | "Cool" | "Neutral" {
  return predictUndertone(skin).label;
}

export function classifyDepth(skin: RGB): "Light" | "Medium" | "Deep" {
  const L = 0.2126 * skin.r + 0.7152 * skin.g + 0.0722 * skin.b;
  if (L > 180) return "Light";
  if (L > 120) return "Medium";
  return "Deep";
}

function contrastScore(skin: RGB, eye?: RGB, hair?: RGB): number {
  if (!eye && !hair) return 0.5;
  const skinL = (skin.r + skin.g + skin.b) / 3;
  const eyeL = eye ? (eye.r + eye.g + eye.b) / 3 : skinL;
  const hairL = hair ? (hair.r + hair.g + hair.b) / 3 : skinL;
  return ((1 - eyeL / 255) + (1 - hairL / 255)) / 2;
}

export function chooseSeason(undertone: "Warm" | "Cool" | "Neutral", depth: "Light" | "Medium" | "Deep", contrast: number): Season {
  if (undertone === "Warm") {
    if (depth === "Light") return contrast > 0.6 ? "Bright Spring" : "Light Spring";
    if (depth === "Medium") return contrast > 0.5 ? "True Spring" : "Warm Autumn";
    return contrast > 0.55 ? "Dark Autumn" : "Deep Autumn";
  }
  if (undertone === "Cool") {
    if (depth === "Light") return contrast > 0.6 ? "Light Summer" : "True Summer";
    if (depth === "Medium") return contrast > 0.55 ? "True Winter" : "Cool Winter";
    return contrast > 0.5 ? "Dark Winter" : "True Winter";
  }
  if (depth === "Light") return contrast > 0.5 ? "Light Summer" : "Soft Summer";
  if (depth === "Medium") return contrast > 0.55 ? "Soft Autumn" : "Soft Summer";
  return "Dark Autumn";
}

export function analyze(skin: RGB, eye?: RGB, hair?: RGB): AnalysisResult {
  const pred = predictUndertone(skin);
  const undertone = pred.label;
  const depth = classifyDepth(skin);
  const contrast = contrastScore(skin, eye, hair);
  const season = chooseSeason(undertone, depth, contrast);
  // Confidence: blend RF top-class probability with contrast signal.
  const conf = Math.min(98, Math.max(55, pred.confidence * 80 + contrast * 18 + 8));
  const harmony = Math.min(99, 70 + contrast * 25);

  // Build season probabilities from undertone probabilities.
  const undertoneOfSeason = (s: Season): "Warm" | "Cool" | "Neutral" => {
    if (/Spring|Autumn/.test(s)) return "Warm";
    if (/Summer|Winter/.test(s)) return "Cool";
    return "Neutral";
  };
  const scored = ALL_SEASONS.map((s) => {
    const base = pred.probs[undertoneOfSeason(s)];
    const bonus = s === season ? 0.35 : 0;
    return { season: s, score: base + bonus + Math.random() * 0.02 };
  }).sort((a, b) => b.score - a.score);
  const top3 = scored.slice(0, 3);
  const sum = top3.reduce((a, c) => a + c.score, 0) || 1;
  const probabilities = top3.map((t, i) => ({
    season: t.season,
    pct: i === 0 ? Math.round(conf) : Math.round((t.score / sum) * conf * 0.9),
  }));

  return { season, undertone, depth, confidence: Math.round(conf), harmony: Math.round(harmony), skin, eye, hair, probabilities };
}

// ------- Sampling -------

export interface SampleOptions {
  /** If multiple faces are present, supply the chosen face box (in original image coords). */
  faceBox?: FaceBox;
  /** If true, throw MultipleFacesError when >1 face is detected. */
  detectMultiple?: boolean;
}

export async function sampleSkinFromImage(file: File, opts: SampleOptions = {}): Promise<RGB> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const W = Math.min(640, img.width);
    const H = Math.round((img.height / img.width) * W);
    const canvas = document.createElement("canvas");
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas unavailable");
    ctx.drawImage(img, 0, 0, W, H);

    let face: FaceBox;
    if (opts.faceBox) {
      // Caller picked a face from the original image — map to working canvas coords.
      const scale = W / img.width;
      face = {
        x: opts.faceBox.x * scale,
        y: opts.faceBox.y * scale,
        width: opts.faceBox.width * scale,
        height: opts.faceBox.height * scale,
        probability: opts.faceBox.probability,
      };
    } else {
      const all = await detectAllFaces(canvas);
      if (all.length === 0) throw new NoFaceError();
      if (opts.detectMultiple && all.length > 1) {
        // Map boxes back to original-image coords for the picker UI.
        const scale = img.width / W;
        const mapped = all.map((b) => ({
          x: b.x * scale, y: b.y * scale,
          width: b.width * scale, height: b.height * scale,
          probability: b.probability,
        }));
        // Build a preview dataURL of the original image at modest size.
        const preview = await blobUrlFromImage(img, 720);
        throw new MultipleFacesError(mapped, img.width, img.height, preview);
      }
      face = all[0];

      const quality = assessFace(face, W, H);
      if (quality.warnings.length > 0) {
        throw new Error(`${quality.warnings.join(" ")}`);
      }
    }

    // Gray-world WB
    const full = ctx.getImageData(0, 0, W, H).data;
    let gr = 0, gg = 0, gb = 0, gn = 0;
    for (let i = 0; i < full.length; i += 4) { gr += full[i]; gg += full[i + 1]; gb += full[i + 2]; gn++; }
    const avg = (gr + gg + gb) / (3 * gn);
    const kr = avg / (gr / gn || 1), kg = avg / (gg / gn || 1), kb = avg / (gb / gn || 1);
    const wb = (R: number, G: number, B: number) => ({
      R: Math.max(0, Math.min(255, R * kr)),
      G: Math.max(0, Math.min(255, G * kg)),
      B: Math.max(0, Math.min(255, B * kb)),
    });

    // Cheek band inside face box
    const sx = Math.max(0, Math.floor(face.x + face.width * 0.18));
    const sy = Math.max(0, Math.floor(face.y + face.height * 0.45));
    const sw = Math.max(1, Math.min(W - sx, Math.floor(face.width * 0.64)));
    const sh = Math.max(1, Math.min(H - sy, Math.floor(face.height * 0.30)));
    const data = ctx.getImageData(sx, sy, sw, sh).data;

    // Lighting check on raw cheek pixels
    let totalL = 0, n = 0;
    for (let i = 0; i < data.length; i += 4) {
      totalL += 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
      n++;
    }
    const meanL = totalL / Math.max(1, n);
    if (meanL < 35) throw new Error("Photo is too dark — please retake in brighter, even light.");
    if (meanL > 240) throw new Error("Photo is overexposed — please retake away from direct sunlight.");

    const candidates: RGB[] = [];
    for (let i = 0; i < data.length; i += 4) {
      const { R, G, B } = wb(data[i], data[i + 1], data[i + 2]);
      const max = Math.max(R, G, B), min = Math.min(R, G, B);
      if (max < 40 || max > 245) continue;
      if (R < G || R < B) continue;
      if (max - min > 95) continue;
      const Cb = 128 - 0.168736 * R - 0.331264 * G + 0.5 * B;
      const Cr = 128 + 0.5 * R - 0.418688 * G - 0.081312 * B;
      if (Cb < 77 || Cb > 135 || Cr < 133 || Cr > 180) continue;
      candidates.push({ r: R, g: G, b: B });
    }
    if (candidates.length < 20) {
      throw new Error("Detected a face but couldn't read skin tones — please retake in even, natural light.");
    }
    candidates.sort((a, b) => (a.r + a.g + a.b) - (b.r + b.g + b.b));
    const lo = Math.floor(candidates.length * 0.2);
    const hi = Math.ceil(candidates.length * 0.8);
    return averageRgb(candidates.slice(lo, hi));
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Build a small JPEG thumbnail (data URL) for diary storage. */
export async function makeThumbnail(file: File, side = 96): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const canvas = document.createElement("canvas");
    const scale = side / Math.min(img.width, img.height);
    const w = Math.round(img.width * scale), h = Math.round(img.height * scale);
    canvas.width = side; canvas.height = side;
    const ctx = canvas.getContext("2d")!;
    // Centre-crop into a square.
    const ox = (w - side) / 2, oy = (h - side) / 2;
    ctx.drawImage(img, -ox, -oy, w, h);
    return canvas.toDataURL("image/jpeg", 0.7);
  } finally { URL.revokeObjectURL(url); }
}

async function blobUrlFromImage(img: HTMLImageElement, maxSide: number): Promise<string> {
  const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale), h = Math.round(img.height * scale);
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  c.getContext("2d")!.drawImage(img, 0, 0, w, h);
  return c.toDataURL("image/jpeg", 0.85);
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

// Re-export so existing imports keep working.
export { detectPrimaryFace };

// Camera calibration uses a plain white surface — no face required.
export async function calibrateFromWhite(file: File): Promise<{ bias: string; offset: RGB }> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const W = 240, H = Math.round((img.height / img.width) * W);
    const canvas = document.createElement("canvas");
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(img, 0, 0, W, H);
    const data = ctx.getImageData(Math.floor(W * 0.3), Math.floor(H * 0.3), Math.floor(W * 0.4), Math.floor(H * 0.4)).data;
    let r = 0, g = 0, b = 0, n = 0;
    for (let i = 0; i < data.length; i += 4) { r += data[i]; g += data[i + 1]; b += data[i + 2]; n++; }
    const rgb = { r: r / n, g: g / n, b: b / n };
    const avg = (rgb.r + rgb.g + rgb.b) / 3;
    const offset = { r: 255 - rgb.r, g: 255 - rgb.g, b: 255 - rgb.b };
    let bias = "Neutral";
    if (rgb.r - rgb.b > 12) bias = "Warm (camera adds yellow)";
    else if (rgb.b - rgb.r > 12) bias = "Cool (camera adds blue)";
    return { bias: `${bias} · avg luminance ${Math.round(avg)}`, offset };
  } finally { URL.revokeObjectURL(url); }
}
