// PDF report builder for Tinta analysis results.
// Extracted so it can be unit-tested headlessly (Node + jsPDF).
import { jsPDF } from "jspdf";
import type { AnalysisResult } from "./analysis";
import type { SeasonData } from "./seasons";

export interface ReportInput extends AnalysisResult {
  skinHex?: string;
}

/**
 * Canonical section labels rendered in the PDF.
 * Tests assert each of these is present in the output.
 */
export const REPORT_SECTIONS = [
  "YOUR BEST COLOURS",
  "COLOURS TO AVOID",
  "MAKEUP RECOMMENDATIONS",
  "CLOTHING & STYLE",
  "JEWELLERY & METALS",
  "WHY THIS WORKS FOR YOU",
  "A NOTE JUST FOR YOU",
] as const;

export function buildReportPdf(current: ReportInput, s: SeasonData): jsPDF {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const PAGE_W = doc.internal.pageSize.getWidth();
  const PAGE_H = doc.internal.pageSize.getHeight();
  const M = 56;
  const INK = [40, 30, 24] as const;
  const MUTED = [120, 110, 100] as const;
  const ACCENT = [200, 120, 60] as const;
  const LINE = [228, 220, 210] as const;

  const hexToRgb = (hex: string) => ({
    r: parseInt(hex.slice(1, 3), 16),
    g: parseInt(hex.slice(3, 5), 16),
    b: parseInt(hex.slice(5, 7), 16),
  });
  const setInk = (c: readonly [number, number, number]) =>
    doc.setTextColor(c[0], c[1], c[2]);
  const hr = (yy: number) => {
    doc.setDrawColor(LINE[0], LINE[1], LINE[2]);
    doc.setLineWidth(0.5);
    doc.line(M, yy, PAGE_W - M, yy);
  };
  const ensure = (yy: number, needed: number) => {
    if (yy + needed > PAGE_H - 80) { doc.addPage(); return M + 20; }
    return yy;
  };
  const sectionLabel = (text: string, yy: number) => {
    setInk(ACCENT);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    doc.text(text.toUpperCase(), M, yy, { charSpace: 1.5 });
    setInk(INK);
  };

  // HEADER
  setInk(ACCENT);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text("TINTA", PAGE_W / 2, 70, { align: "center", charSpace: 4 });
  setInk(MUTED);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.text("AI \u00B7 PERSONAL COLOUR ANALYSIS", PAGE_W / 2, 84, { align: "center", charSpace: 2 });
  hr(104);

  // HERO
  setInk(INK);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(34);
  doc.text(current.season, PAGE_W / 2, 148, { align: "center" });
  setInk(MUTED);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text(`${current.undertone} Undertone \u00B7 ${current.depth} Depth`, PAGE_W / 2, 168, { align: "center" });
  setInk(INK);
  doc.setFontSize(10.5);
  const moodLines = doc.splitTextToSize(s.mood, PAGE_W - M * 2 - 40);
  doc.text(moodLines, PAGE_W / 2, 192, { align: "center" });

  // STATS
  let y = 230;
  const colW = (PAGE_W - M * 2) / 3;
  const skinHex = current.skinHex || s.foundation.hex;
  doc.setFillColor(252, 244, 236);
  doc.roundedRect(M, y, PAGE_W - M * 2, 64, 4, 4, "F");
  doc.setDrawColor(LINE[0], LINE[1], LINE[2]);
  doc.line(M + colW, y + 12, M + colW, y + 52);
  doc.line(M + colW * 2, y + 12, M + colW * 2, y + 52);
  const stat = (label: string, value: string, idx: number) => {
    const cx = M + colW * idx + colW / 2;
    setInk(MUTED);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(label.toUpperCase(), cx, y + 24, { align: "center", charSpace: 1 });
    setInk(INK);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(15);
    doc.text(value, cx, y + 48, { align: "center" });
  };
  stat("Confidence", `${current.confidence}%`, 0);
  stat("Harmony", `${current.harmony}%`, 1);
  stat("Detected Skin", String(skinHex).toUpperCase(), 2);
  y += 96;

  // PALETTE
  sectionLabel("Your Best Colours", y); y += 18;
  const swatchGap = 8;
  const swatchW = (PAGE_W - M * 2 - swatchGap * (s.palette.length - 1)) / s.palette.length;
  const swatchH = 70;
  s.palette.forEach((col, i) => {
    const { r, g, b } = hexToRgb(col);
    const x = M + i * (swatchW + swatchGap);
    doc.setFillColor(r, g, b);
    doc.roundedRect(x, y, swatchW, swatchH, 3, 3, "F");
    const lum = (r * 299 + g * 587 + b * 114) / 1000;
    doc.setTextColor(lum > 150 ? 60 : 255, lum > 150 ? 50 : 255, lum > 150 ? 45 : 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7);
    doc.text(col.toUpperCase(), x + swatchW / 2, y + swatchH / 2 + 2, { align: "center" });
  });
  y += swatchH + 28;

  // AVOID
  y = ensure(y, 100);
  sectionLabel("Colours to Avoid", y); y += 18;
  const avoidList = [s.avoid, "#FFFFFF", "#C0C0C0", "#E6E6FA"];
  const avW = (PAGE_W - M * 2 - swatchGap * 3) / 4;
  avoidList.forEach((col, i) => {
    const { r, g, b } = hexToRgb(col);
    const x = M + i * (avW + swatchGap);
    doc.setFillColor(r, g, b);
    doc.setDrawColor(LINE[0], LINE[1], LINE[2]);
    doc.roundedRect(x, y, avW, 50, 3, 3, "FD");
    const lum = (r * 299 + g * 587 + b * 114) / 1000;
    doc.setTextColor(lum > 150 ? 80 : 255, lum > 150 ? 70 : 255, lum > 150 ? 65 : 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7);
    doc.text(col.toUpperCase(), x + avW / 2, y + 28, { align: "center" });
  });
  y += 78;

  // MAKEUP
  y = ensure(y, 110);
  sectionLabel("Makeup Recommendations", y); y += 20;
  const makeupRow = (label: string, brand: string, name: string, hex: string) => {
    setInk(INK);
    doc.setFont("helvetica", "bold"); doc.setFontSize(10);
    doc.text(`${label}:`, M, y);
    doc.setFont("helvetica", "normal");
    const lw = doc.getTextWidth(`${label}: `);
    doc.text(`${brand} \u2014 ${name}`, M + lw, y);
    const { r, g, b } = hexToRgb(hex);
    doc.setFillColor(r, g, b);
    doc.circle(PAGE_W - M - 34, y - 3, 4, "F");
    setInk(MUTED); doc.setFontSize(8.5);
    doc.text(hex.toUpperCase(), PAGE_W - M - 26, y);
    setInk(INK);
    y += 18;
  };
  makeupRow("Foundation", s.foundation.brand, s.foundation.name, s.foundation.hex);
  makeupRow("Lipstick", s.lipstick.brand, s.lipstick.name, s.lipstick.hex);
  makeupRow("Blush", s.blush.brand, s.blush.name, s.blush.hex);
  y += 8;

  // CLOTHING
  y = ensure(y, 110);
  hr(y); y += 22;
  sectionLabel("Clothing & Style", y); y += 20;
  const styleRow = (label: string, value: string) => {
    doc.setFont("helvetica", "bold"); doc.setFontSize(10); setInk(INK);
    doc.text(`${label}:`, M, y);
    doc.setFont("helvetica", "normal");
    const lw = doc.getTextWidth(`${label}: `);
    const lines = doc.splitTextToSize(value, PAGE_W - M * 2 - lw);
    doc.text(lines, M + lw, y);
    y += lines.length * 14 + 4;
  };
  styleRow("Best colours", s.clothing.join(" \u00B7 "));
  styleRow("Fabrics", "Suede, corduroy, raw silk, chunky knits \u2014 textures with real depth.");
  styleRow("Patterns", "Earthy plaids, abstract botanical, tortoiseshell, leopard.");

  // JEWELLERY
  y = ensure(y, 70); y += 6;
  hr(y); y += 22;
  sectionLabel("Jewellery & Metals", y); y += 20;
  doc.setFont("helvetica", "bold"); doc.setFontSize(12); setInk(INK);
  doc.text(s.jewelry, M, y); y += 14;
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); setInk(MUTED);
  doc.text(`Try: ${s.jewelryBrand}`, M, y); y += 26;

  // WHY
  y = ensure(y, 90);
  hr(y); y += 22;
  sectionLabel("Why This Works for You", y); y += 18;
  setInk(INK); doc.setFont("helvetica", "normal"); doc.setFontSize(10.5);
  const whyLines = doc.splitTextToSize(
    `Your ${current.undertone.toLowerCase()} ${current.depth.toLowerCase()} colouring pairs beautifully with this palette. ${s.mood}`,
    PAGE_W - M * 2
  );
  doc.text(whyLines, M, y);
  y += whyLines.length * 14 + 18;

  // NOTE
  y = ensure(y, 80);
  hr(y); y += 22;
  sectionLabel("A Note Just for You", y); y += 20;
  setInk(INK); doc.setFont("helvetica", "italic"); doc.setFontSize(11);
  const noteLines = doc.splitTextToSize(`"${s.affirmation}"`, PAGE_W - M * 2);
  doc.text(noteLines, M, y);

  // FOOTER on each page
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    setInk(MUTED);
    doc.setFont("helvetica", "normal"); doc.setFontSize(8);
    const stamp = new Date().toLocaleDateString("en-GB", {
      day: "numeric", month: "short", year: "numeric",
    });
    doc.text(`Generated by Tinta \u00B7 ${stamp}`, PAGE_W / 2, PAGE_H - 48, { align: "center" });
    doc.setFontSize(7.5);
    doc.text(
      "Results are a guide. Professional colour draping gives maximum precision.",
      PAGE_W / 2, PAGE_H - 36, { align: "center" }
    );
  }

  return doc;
}
