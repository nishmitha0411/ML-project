// Human-face detection using @vladmandic/face-api (TinyFaceDetector).
// Model weights are bundled in /public/models/face-api so detection works
// without external CDNs. No image data ever leaves the device.
//
// If no human face is detected, sampling throws NoFaceError — the app refuses
// to analyze non-face images, which is the whole point of the project.

const MODEL_URL = "/models/face-api";
type FaceApi = typeof import("@vladmandic/face-api");

type NativeFace = { boundingBox: DOMRectReadOnly | { x: number; y: number; width: number; height: number } };

declare global {
  interface Window {
    FaceDetector?: new (options?: { fastMode?: boolean; maxDetectedFaces?: number }) => {
      detect: (image: HTMLImageElement | HTMLCanvasElement) => Promise<NativeFace[]>;
    };
  }
}

export interface FaceBox {
  x: number;
  y: number;
  width: number;
  height: number;
  /** detector confidence in [0,1] */
  probability: number;
}

export interface FaceQuality {
  box: FaceBox;
  coverage: number;
  offCenter: number;
  warnings: string[];
}

export class FaceModelUnavailableError extends Error {
  constructor() {
    super("Face detection is unavailable right now. Please refresh the page and try again.");
    this.name = "FaceModelUnavailableError";
  }
}

let modelPromise: Promise<void> | null = null;
let ssdModelPromise: Promise<void> | null = null;
let faceApiPromise: Promise<FaceApi> | null = null;

function loadFaceApi(): Promise<FaceApi> {
  if (typeof window === "undefined") {
    return Promise.reject(new FaceModelUnavailableError());
  }
  if (!faceApiPromise) {
    // Dynamic import keeps the heavy face-api bundle (and its Node-only
    // fallback path) out of SSR and out of the initial client bundle.
    faceApiPromise = import("@vladmandic/face-api");
  }
  return faceApiPromise;
}

function loadModel(): Promise<void> {
  if (!modelPromise) {
    modelPromise = loadFaceApi().then((faceapi) => faceapi.nets.tinyFaceDetector
      .loadFromUri(MODEL_URL)
      .catch((err) => {
        modelPromise = null;
        console.error("Local face detection model failed to load", err);
        throw new FaceModelUnavailableError();
      }));
  }
  return modelPromise;
}

function loadSsdModel(): Promise<void> {
  if (!ssdModelPromise) {
    ssdModelPromise = loadFaceApi().then((faceapi) => faceapi.nets.ssdMobilenetv1
      .loadFromUri(MODEL_URL)
      .catch((err) => {
        ssdModelPromise = null;
        console.error("Accurate face detection model failed to load", err);
        throw new FaceModelUnavailableError();
      }));
  }
  return ssdModelPromise;
}

let landmarkModelPromise: Promise<void> | null = null;
function loadLandmarkModel(): Promise<void> {
  if (!landmarkModelPromise) {
    landmarkModelPromise = loadFaceApi().then((faceapi) => faceapi.nets.faceLandmark68Net
      .loadFromUri(MODEL_URL)
      .catch((err) => {
        landmarkModelPromise = null;
        console.error("Face landmark model failed to load", err);
        throw new FaceModelUnavailableError();
      }));
  }
  return landmarkModelPromise;
}

/**
 * Verify a detected box is actually a HUMAN face (not cartoon/animal/object)
 * by fitting 68 landmarks and checking human face geometry: eyes aligned
 * horizontally, nose between eyes, mouth below nose, sane interocular ratio.
 * The landmark net is trained on real human faces and produces incoherent
 * points on non-humans, which fail these geometric sanity checks.
 */
async function isHumanFace(
  img: HTMLImageElement | HTMLCanvasElement,
  box: FaceBox,
): Promise<boolean> {
  try {
    await loadLandmarkModel();
    const faceapi = await loadFaceApi();
    const pad = Math.max(box.width, box.height) * 0.35;
    const sx = Math.max(0, Math.floor(box.x - pad));
    const sy = Math.max(0, Math.floor(box.y - pad));
    const imgW = (img as HTMLImageElement).naturalWidth || (img as HTMLCanvasElement).width;
    const imgH = (img as HTMLImageElement).naturalHeight || (img as HTMLCanvasElement).height;
    const sw = Math.min(imgW - sx, Math.floor(box.width + pad * 2));
    const sh = Math.min(imgH - sy, Math.floor(box.height + pad * 2));
    if (sw < 32 || sh < 32) return false;
    const crop = document.createElement("canvas");
    crop.width = sw;
    crop.height = sh;
    crop.getContext("2d")!.drawImage(img as CanvasImageSource, sx, sy, sw, sh, 0, 0, sw, sh);

    const raw = await faceapi.detectFaceLandmarks(crop);
    const landmarks = Array.isArray(raw) ? raw[0] : raw;
    const pts = landmarks?.positions;
    if (!pts || pts.length < 68) return false;

    const leftEye = pts.slice(36, 42);
    const rightEye = pts.slice(42, 48);
    const nose = pts[30];
    const mouthTop = pts[51];
    const mouthBottom = pts[57];

    const avg = (arr: { x: number; y: number }[]) => ({
      x: arr.reduce((s, p) => s + p.x, 0) / arr.length,
      y: arr.reduce((s, p) => s + p.y, 0) / arr.length,
    });
    const le = avg(leftEye);
    const re = avg(rightEye);
    const eyeDx = re.x - le.x;
    const eyeDy = Math.abs(re.y - le.y);
    if (eyeDx <= 0) return false;

    const interocular = Math.hypot(eyeDx, re.y - le.y);
    const ratio = interocular / sw;
    if (ratio < 0.15 || ratio > 0.75) return false;
    if (eyeDy / eyeDx > 0.7) return false;

    const eyeMidX = (le.x + re.x) / 2;
    const eyeMidY = (le.y + re.y) / 2;
    if (Math.abs(nose.x - eyeMidX) > interocular * 0.8) return false;
    if (nose.y <= eyeMidY) return false;
    if (mouthTop.y <= nose.y) return false;
    if (mouthBottom.y <= mouthTop.y) return false;
    const noseToMouth = mouthTop.y - eyeMidY;
    if (noseToMouth < interocular * 0.4 || noseToMouth > interocular * 2.5) return false;

    return true;
  } catch (err) {
    console.warn("Landmark verification failed", err);
    return false;
  }
}

async function detectWithNativeFaceDetector(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[] | null> {
  if (typeof window === "undefined" || !window.FaceDetector) return null;
  try {
    const detector = new window.FaceDetector({ fastMode: true, maxDetectedFaces: 8 });
    const faces = await detector.detect(img);
    return faces
      .map((face) => ({
        x: Math.max(0, face.boundingBox.x),
        y: Math.max(0, face.boundingBox.y),
        width: Math.max(0, face.boundingBox.width),
        height: Math.max(0, face.boundingBox.height),
        probability: 0.95,
      }))
      .filter((b) => b.width > 24 && b.height > 24)
      .sort((a, b) => b.width * b.height - a.width * a.height);
  } catch {
    return null;
  }
}

async function detectWithFaceApi(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[]> {
  await loadModel();
  const faceapi = await loadFaceApi();
  // Run a strict pass first, then a larger/lower-threshold pass for real selfies
  // with side angles, darker skin, flat studio backgrounds, or phone compression.
  const passes = [
    new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.38 }),
    new faceapi.TinyFaceDetectorOptions({ inputSize: 608, scoreThreshold: 0.25 }),
  ];
  let results: Array<{ box: { x: number; y: number; width: number; height: number }; score: number }> = [];
  for (const options of passes) {
    results = await faceapi.detectAllFaces(img as HTMLImageElement, options);
    if (results.length > 0) break;
  }
  if (results.length === 0) {
    await loadSsdModel();
    results = await faceapi.detectAllFaces(
      img as HTMLImageElement,
      new faceapi.SsdMobilenetv1Options({ minConfidence: 0.2, maxResults: 8 }),
    );
  }
  return results
    .map((r) => ({
      x: Math.max(0, r.box.x),
      y: Math.max(0, r.box.y),
      width: Math.max(0, r.box.width),
      height: Math.max(0, r.box.height),
      probability: r.score,
    }))
    .filter((b) => b.probability >= 0.2 && b.width > 24 && b.height > 24)
    .sort((a, b) => b.width * b.height - a.width * a.height);
}

async function detectAll(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[]> {
  const native = await detectWithNativeFaceDetector(img);
  const candidates = native && native.length > 0 ? native : await detectWithFaceApi(img);
  if (candidates.length === 0) return [];
  // Verify each candidate is a real HUMAN face via 68-pt landmark geometry.
  // Cartoons, animals, masks, and pareidolia are filtered out here.
  const verified: FaceBox[] = [];
  for (const c of candidates) {
    if (await isHumanFace(img, c)) verified.push(c);
  }
  return verified;
}

/** All faces in the image (sorted largest first). */
export async function detectAllFaces(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[]> {
  return detectAll(img);
}

/** The single most prominent face, or null if none. */
export async function detectPrimaryFace(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox | null> {
  const all = await detectAll(img);
  return all[0] ?? null;
}

/** Inspect face quality against the source image dimensions. */
export function assessFace(box: FaceBox, imgW: number, imgH: number): FaceQuality {
  const area = box.width * box.height;
  const coverage = area / (imgW * imgH);
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  const offCenter = Math.hypot((cx - imgW / 2) / (imgW / 2), (cy - imgH / 2) / (imgH / 2));
  const warnings: string[] = [];
  if (coverage < 0.012) warnings.push("Face is small — move closer to the camera.");
  return { box, coverage, offCenter, warnings };
}

/** Warm the model in the background so the first analysis isn't slow. */
export function preloadFaceModel() {
  void loadModel().catch(() => {
    /* will retry on demand */
  });
}
