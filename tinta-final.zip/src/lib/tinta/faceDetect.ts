// Human-face detection using @vladmandic/face-api (TinyFaceDetector).
// Model weights are bundled in /public/models/face-api so detection works
// without external CDNs. No image data ever leaves the device.
//
// If no human face is detected, sampling throws NoFaceError — the app refuses
// to analyze non-face images, which is the whole point of the project.

const MODEL_URL = "/models/face-api";
type FaceApi = typeof import("@vladmandic/face-api");

type NativeFace = { boundingBox: DOMRectReadOnly | { x: number; y: number; width: number; height: number } };

declare global {
  interface Window {
    FaceDetector?: new (options?: { fastMode?: boolean; maxDetectedFaces?: number }) => {
      detect: (image: HTMLImageElement | HTMLCanvasElement) => Promise<NativeFace[]>;
    };
  }
}

export interface FaceBox {
  x: number;
  y: number;
  width: number;
  height: number;
  /** detector confidence in [0,1] */
  probability: number;
}

export interface FaceQuality {
  box: FaceBox;
  coverage: number;
  offCenter: number;
  warnings: string[];
}

export class FaceModelUnavailableError extends Error {
  constructor() {
    super("Face detection is unavailable right now. Please refresh the page and try again.");
    this.name = "FaceModelUnavailableError";
  }
}

let modelPromise: Promise<void> | null = null;
let ssdModelPromise: Promise<void> | null = null;
let faceApiPromise: Promise<FaceApi> | null = null;

function loadFaceApi(): Promise<FaceApi> {
  if (typeof window === "undefined") {
    return Promise.reject(new FaceModelUnavailableError());
  }
  if (!faceApiPromise) {
    // Dynamic import keeps the heavy face-api bundle (and its Node-only
    // fallback path) out of SSR and out of the initial client bundle.
    faceApiPromise = import("@vladmandic/face-api");
  }
  return faceApiPromise;
}

function loadModel(): Promise<void> {
  if (!modelPromise) {
    modelPromise = loadFaceApi().then((faceapi) => faceapi.nets.tinyFaceDetector
      .loadFromUri(MODEL_URL)
      .catch((err) => {
        modelPromise = null;
        console.error("Local face detection model failed to load", err);
        throw new FaceModelUnavailableError();
      }));
  }
  return modelPromise;
}

function loadSsdModel(): Promise<void> {
  if (!ssdModelPromise) {
    ssdModelPromise = loadFaceApi().then((faceapi) => faceapi.nets.ssdMobilenetv1
      .loadFromUri(MODEL_URL)
      .catch((err) => {
        ssdModelPromise = null;
        console.error("Accurate face detection model failed to load", err);
        throw new FaceModelUnavailableError();
      }));
  }
  return ssdModelPromise;
}

async function detectWithNativeFaceDetector(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[] | null> {
  if (typeof window === "undefined" || !window.FaceDetector) return null;
  try {
    const detector = new window.FaceDetector({ fastMode: true, maxDetectedFaces: 8 });
    const faces = await detector.detect(img);
    return faces
      .map((face) => ({
        x: Math.max(0, face.boundingBox.x),
        y: Math.max(0, face.boundingBox.y),
        width: Math.max(0, face.boundingBox.width),
        height: Math.max(0, face.boundingBox.height),
        probability: 0.95,
      }))
      .filter((b) => b.width > 24 && b.height > 24)
      .sort((a, b) => b.width * b.height - a.width * a.height);
  } catch {
    return null;
  }
}

async function detectWithFaceApi(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[]> {
  await loadModel();
  const faceapi = await loadFaceApi();
  // Run a strict pass first, then a larger/lower-threshold pass for real selfies
  // with side angles, darker skin, flat studio backgrounds, or phone compression.
  const passes = [
    new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.38 }),
    new faceapi.TinyFaceDetectorOptions({ inputSize: 608, scoreThreshold: 0.25 }),
  ];
  let results: Array<{ box: { x: number; y: number; width: number; height: number }; score: number }> = [];
  for (const options of passes) {
    results = await faceapi.detectAllFaces(img as HTMLImageElement, options);
    if (results.length > 0) break;
  }
  if (results.length === 0) {
    await loadSsdModel();
    results = await faceapi.detectAllFaces(
      img as HTMLImageElement,
      new faceapi.SsdMobilenetv1Options({ minConfidence: 0.2, maxResults: 8 }),
    );
  }
  return results
    .map((r) => ({
      x: Math.max(0, r.box.x),
      y: Math.max(0, r.box.y),
      width: Math.max(0, r.box.width),
      height: Math.max(0, r.box.height),
      probability: r.score,
    }))
    .filter((b) => b.probability >= 0.2 && b.width > 24 && b.height > 24)
    .sort((a, b) => b.width * b.height - a.width * a.height);
}

async function detectAll(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[]> {
  const nativeFaces = await detectWithNativeFaceDetector(img);
  if (nativeFaces && nativeFaces.length > 0) return nativeFaces;
  return detectWithFaceApi(img);
}

/** All faces in the image (sorted largest first). */
export async function detectAllFaces(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox[]> {
  return detectAll(img);
}

/** The single most prominent face, or null if none. */
export async function detectPrimaryFace(img: HTMLImageElement | HTMLCanvasElement): Promise<FaceBox | null> {
  const all = await detectAll(img);
  return all[0] ?? null;
}

/** Inspect face quality against the source image dimensions. */
export function assessFace(box: FaceBox, imgW: number, imgH: number): FaceQuality {
  const area = box.width * box.height;
  const coverage = area / (imgW * imgH);
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  const offCenter = Math.hypot((cx - imgW / 2) / (imgW / 2), (cy - imgH / 2) / (imgH / 2));
  const warnings: string[] = [];
  if (coverage < 0.012) warnings.push("Face is small — move closer to the camera.");
  return { box, coverage, offCenter, warnings };
}

/** Warm the model in the background so the first analysis isn't slow. */
export function preloadFaceModel() {
  void loadModel().catch(() => {
    /* will retry on demand */
  });
}
