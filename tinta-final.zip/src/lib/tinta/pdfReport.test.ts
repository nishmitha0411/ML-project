import { describe, it, expect } from "vitest";
import { buildReportPdf, REPORT_SECTIONS } from "./pdfReport";
import { SEASONS, type Season } from "./seasons";
import type { AnalysisResult } from "./analysis";

/**
 * Per-mode smoke fixtures. Each entry mirrors what `current` looks like after
 * one of the 6 analysis modes runs successfully, so we can confirm the PDF
 * report contains the right season / undertone / depth / feature sections.
 */
const MODE_FIXTURES: {
  mode: string;
  season: Season;
  undertone: AnalysisResult["undertone"];
  depth: AnalysisResult["depth"];
}[] = [
  { mode: "single",     season: "True Autumn"   as Season, undertone: "Warm",    depth: "Medium" },
  { mode: "multi",      season: "Soft Summer",              undertone: "Cool",    depth: "Light"  },
  { mode: "manual",     season: "Deep Autumn",              undertone: "Warm",    depth: "Deep"   },
  { mode: "quiz",       season: "True Winter",              undertone: "Cool",    depth: "Deep"   },
  { mode: "compare",    season: "Light Spring",             undertone: "Warm",    depth: "Light"  },
  { mode: "calibrate",  season: "True Summer",              undertone: "Neutral", depth: "Medium" },
];

const SEASON_FALLBACK: Season = "Light Spring";

function makeResult(f: typeof MODE_FIXTURES[number]): AnalysisResult {
  const seasonKey: Season = SEASONS[f.season] ? f.season : SEASON_FALLBACK;
  return {
    season: seasonKey,
    undertone: f.undertone,
    depth: f.depth,
    confidence: 87,
    harmony: 92,
    skin: { r: 210, g: 170, b: 140 },
    probabilities: [
      { season: seasonKey, pct: 87 },
      { season: SEASON_FALLBACK, pct: 8 },
      { season: "Soft Autumn" as Season, pct: 5 },
    ],
  };
}

/**
 * jsPDF embeds helvetica text as plain ASCII (winansi) inside the PDF byte
 * stream, so a substring search on the raw output is enough to confirm a
 * label was actually drawn — no PDF parser needed.
 */
function pdfText(f: typeof MODE_FIXTURES[number]): string {
  const result = makeResult(f);
  const seasonKey = result.season;
  const season = SEASONS[seasonKey];
  expect(season, `season data exists for ${seasonKey}`).toBeTruthy();
  const doc = buildReportPdf({ ...result, skinHex: "#D2AA8C" }, season);
  return doc.output("arraybuffer") instanceof ArrayBuffer
    ? Buffer.from(doc.output("arraybuffer")).toString("latin1")
    : (doc.output() as string);
}

describe("PDF report content per mode", () => {
  for (const fixture of MODE_FIXTURES) {
    it(`[${fixture.mode}] includes season, undertone, depth, and all feature sections`, () => {
      const raw = pdfText(fixture);
      const result = makeResult(fixture);

      // Season name (hero title)
      expect(raw, "season name present").toContain(result.season);
      // Undertone + depth subtitle
      expect(raw, "undertone present").toContain(`${result.undertone} Undertone`);
      expect(raw, "depth present").toContain(`${result.depth} Depth`);
      // Every feature section label
      for (const label of REPORT_SECTIONS) {
        expect(raw, `section "${label}" present`).toContain(label);
      }
    });
  }
});
