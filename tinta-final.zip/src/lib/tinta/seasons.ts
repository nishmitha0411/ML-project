// 12-season color system data for Tinta
export type Season =
  | "Light Spring" | "Bright Spring" | "True Spring" | "Warm Autumn"
  | "Deep Autumn" | "Dark Autumn" | "Light Summer" | "True Summer"
  | "Cool Winter" | "True Winter" | "Dark Winter" | "Soft Summer"
  | "Soft Autumn";

export interface SeasonData {
  palette: string[];      // 6 hex colors
  vibe: string;
  emoji: string;
  mood: string;
  celebrity: string;
  celebReason: string;
  spotify: string;
  pinterest: string;
  lipstick: { brand: string; name: string; hex: string };
  blush: { brand: string; name: string; hex: string };
  foundation: { brand: string; name: string; hex: string };
  clothing: string[];
  jewelry: string;
  jewelryBrand: string;
  affirmation: string;
  avoid: string;
}

export const SEASONS: Record<string, SeasonData> = {
  "Light Spring": {
    palette: ["#F8D7C4", "#FFE8B0", "#C8E6C9", "#A8DADC", "#FFB5A7", "#F4A261"],
    vibe: "Fresh Morning Bloom", emoji: "🌷",
    mood: "Light, airy, and full of soft warmth like sunrise over peach gardens.",
    celebrity: "Nicole Kidman", celebReason: "warm fair skin with golden undertones",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX0SM0LYsmbMT",
    pinterest: "https://www.pinterest.com/search/pins/?q=light%20spring%20outfit",
    lipstick: { brand: "Glossier", name: "Generation G in Cake", hex: "#E8A595" },
    blush: { brand: "Rare Beauty", name: "Joy", hex: "#F4B5A0" },
    foundation: { brand: "NARS", name: "Sheer Glow Mont Blanc", hex: "#F5D6B8" },
    clothing: ["#FFE8B0", "#C8E6C9", "#F8D7C4", "#FFB5A7", "#A8DADC"],
    jewelry: "Yellow gold, rose gold", jewelryBrand: "Mejuri",
    affirmation: "I radiate warmth and gentle joy.", avoid: "#1A1A1A",
  },
  "Bright Spring": {
    palette: ["#FF4D6D", "#FFD60A", "#06D6A0", "#118AB2", "#EF476F", "#FFB703"],
    vibe: "Electric Citrus Burst", emoji: "⚡",
    mood: "Vivid, high-contrast, and joyfully loud — neon meets daylight.",
    celebrity: "Anne Hathaway", celebReason: "bright eyes with high contrast",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M",
    pinterest: "https://www.pinterest.com/search/pins/?q=bright%20spring%20outfit",
    lipstick: { brand: "MAC", name: "Ruby Woo", hex: "#D6304F" },
    blush: { brand: "NARS", name: "Orgasm", hex: "#E08A7A" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 200", hex: "#E3BA94" },
    clothing: ["#FF4D6D", "#FFD60A", "#06D6A0", "#118AB2", "#FFB703"],
    jewelry: "Polished yellow gold", jewelryBrand: "Missoma",
    affirmation: "My energy lights up every room.", avoid: "#A9A9A9",
  },
  "True Spring": {
    palette: ["#F4A261", "#E76F51", "#E9C46A", "#2A9D8F", "#FF9F1C", "#FB8500"],
    vibe: "Golden Hour Glow", emoji: "🌞",
    mood: "Warm, clear and sunlit — buttercream and terracotta singing together.",
    celebrity: "Jessica Chastain", celebReason: "warm golden skin and copper hair",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX2sUQwD7tbmL",
    pinterest: "https://www.pinterest.com/search/pins/?q=true%20spring%20outfit",
    lipstick: { brand: "Charlotte Tilbury", name: "Sexy Sienna", hex: "#C56A4A" },
    blush: { brand: "Rare Beauty", name: "Hope", hex: "#E89070" },
    foundation: { brand: "NARS", name: "Sheer Glow Stromboli", hex: "#D4A574" },
    clothing: ["#F4A261", "#E76F51", "#E9C46A", "#2A9D8F", "#FB8500"],
    jewelry: "Warm yellow gold, copper", jewelryBrand: "Catbird",
    affirmation: "I shine with golden, grounded warmth.", avoid: "#000000",
  },
  "Warm Autumn": {
    palette: ["#8B4513", "#CD853F", "#DAA520", "#556B2F", "#A0522D", "#BC8F5C"],
    vibe: "Spiced Harvest Velvet", emoji: "🍂",
    mood: "Earthy, rich, and softly smoky — chestnut, paprika, mossy gold.",
    celebrity: "Julia Roberts", celebReason: "auburn hair with warm hazel eyes",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX4o1oenSJRJd",
    pinterest: "https://www.pinterest.com/search/pins/?q=warm%20autumn%20outfit",
    lipstick: { brand: "MAC", name: "Taupe", hex: "#A35A4A" },
    blush: { brand: "NARS", name: "Taos", hex: "#B97560" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 320", hex: "#C68F65" },
    clothing: ["#8B4513", "#CD853F", "#DAA520", "#556B2F", "#A0522D"],
    jewelry: "Antique gold, bronze", jewelryBrand: "Mejuri",
    affirmation: "I am rooted, abundant, and beautifully warm.", avoid: "#E0E0E0",
  },
  "Deep Autumn": {
    palette: ["#3E2723", "#5D4037", "#8B6914", "#1B4332", "#7B2D26", "#9C6644"],
    vibe: "Smoldering Ember Forest", emoji: "🔥",
    mood: "Deep, smoky, and intensely warm — burgundy embers in dark wood.",
    celebrity: "Eva Mendes", celebReason: "deep warm skin with rich dark hair",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX9wC1KY45plY",
    pinterest: "https://www.pinterest.com/search/pins/?q=deep%20autumn%20outfit",
    lipstick: { brand: "Fenty", name: "Stunna Uncuffed", hex: "#7A2D2D" },
    blush: { brand: "NARS", name: "Exhibit A", hex: "#A6493A" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 420", hex: "#8C5A3C" },
    clothing: ["#3E2723", "#5D4037", "#8B6914", "#1B4332", "#7B2D26"],
    jewelry: "Burnished gold, bronze", jewelryBrand: "Missoma",
    affirmation: "My depth is my magnetism.", avoid: "#FFC0CB",
  },
  "Dark Autumn": {
    palette: ["#2D1B14", "#4A2C2A", "#8B4513", "#1F2421", "#6B2737", "#A0522D"],
    vibe: "Midnight Spice Library", emoji: "📚",
    mood: "Velvet dark with glints of copper — like leather books and red wine.",
    celebrity: "Mila Kunis", celebReason: "deep brown eyes and warm dark hair",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX4UtSsGT1Sbe",
    pinterest: "https://www.pinterest.com/search/pins/?q=dark%20autumn%20outfit",
    lipstick: { brand: "MAC", name: "Diva", hex: "#6E2237" },
    blush: { brand: "NARS", name: "Sin", hex: "#9B4A4A" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 380", hex: "#A06F49" },
    clothing: ["#2D1B14", "#4A2C2A", "#8B4513", "#6B2737", "#A0522D"],
    jewelry: "Dark gold, copper", jewelryBrand: "Catbird",
    affirmation: "I am rich, layered, and quietly powerful.", avoid: "#FFFFFF",
  },
  "Light Summer": {
    palette: ["#E0BBE4", "#957DAD", "#D4A5A5", "#A8DADC", "#C9DFEC", "#FEC8D8"],
    vibe: "Misty Pastel Garden", emoji: "💐",
    mood: "Cool, soft and dewy — watercolor florals at dawn.",
    celebrity: "Reese Witherspoon", celebReason: "cool fair skin with blonde hair",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX4sWSpwq3LiO",
    pinterest: "https://www.pinterest.com/search/pins/?q=light%20summer%20outfit",
    lipstick: { brand: "Glossier", name: "Ultralip Portrait", hex: "#D89AA5" },
    blush: { brand: "Rare Beauty", name: "Bliss", hex: "#E8B0BC" },
    foundation: { brand: "NARS", name: "Sheer Glow Deauville", hex: "#EFCFB0" },
    clothing: ["#E0BBE4", "#957DAD", "#A8DADC", "#C9DFEC", "#FEC8D8"],
    jewelry: "Silver, white gold, platinum", jewelryBrand: "Mejuri",
    affirmation: "My softness is a quiet strength.", avoid: "#FF6600",
  },
  "True Summer": {
    palette: ["#6A8CAF", "#A8B8D8", "#C9A0DC", "#88B0B8", "#B8A0C8", "#5B7B9C"],
    vibe: "Sea Glass Morning", emoji: "🌊",
    mood: "Cool, muted and serene — fog rolling over slate seas.",
    celebrity: "Jacqueline Kennedy", celebReason: "classic cool tones with elegant restraint",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DXbm0dp7JzNeL",
    pinterest: "https://www.pinterest.com/search/pins/?q=true%20summer%20outfit",
    lipstick: { brand: "NARS", name: "Audacious Anita", hex: "#B05A78" },
    blush: { brand: "NARS", name: "Mata Hari", hex: "#A85970" },
    foundation: { brand: "NARS", name: "Sheer Glow Ceylan", hex: "#D9B795" },
    clothing: ["#6A8CAF", "#A8B8D8", "#C9A0DC", "#88B0B8", "#5B7B9C"],
    jewelry: "Silver, white gold", jewelryBrand: "Missoma",
    affirmation: "I am calm, composed, and quietly luminous.", avoid: "#FF8C00",
  },
  "Soft Summer": {
    palette: ["#9CAEA9", "#B5A8A0", "#A8A4B5", "#C9B0B0", "#8B9DA8", "#BCAE9F"],
    vibe: "Cashmere Whisper", emoji: "🕊️",
    mood: "Dusty, muted and elegant — pressed flowers in linen.",
    celebrity: "Drew Barrymore", celebReason: "soft cool tones with neutral balance",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DWZqd5JICZI0u",
    pinterest: "https://www.pinterest.com/search/pins/?q=soft%20summer%20outfit",
    lipstick: { brand: "Charlotte Tilbury", name: "Pillow Talk", hex: "#C28A82" },
    blush: { brand: "Rare Beauty", name: "Grateful", hex: "#C49890" },
    foundation: { brand: "NARS", name: "Light Reflecting Salzburg", hex: "#D9B59A" },
    clothing: ["#9CAEA9", "#B5A8A0", "#A8A4B5", "#C9B0B0", "#8B9DA8"],
    jewelry: "Brushed silver, matte gold", jewelryBrand: "Catbird",
    affirmation: "I bloom in soft, considered light.", avoid: "#FF0000",
  },
  "Cool Winter": {
    palette: ["#0A1828", "#178582", "#BFA181", "#9C0F3D", "#E8E8E8", "#1E3A5F"],
    vibe: "Frozen Sapphire", emoji: "❄️",
    mood: "Sharp, cool and dramatic — ice with magenta lightning.",
    celebrity: "Lucy Liu", celebReason: "cool undertones with high contrast features",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DXcF6B6QPhFDv",
    pinterest: "https://www.pinterest.com/search/pins/?q=cool%20winter%20outfit",
    lipstick: { brand: "MAC", name: "Russian Red", hex: "#A8123B" },
    blush: { brand: "NARS", name: "Desire", hex: "#D6606E" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 240", hex: "#D2A685" },
    clothing: ["#0A1828", "#178582", "#9C0F3D", "#E8E8E8", "#1E3A5F"],
    jewelry: "Platinum, silver, white gold", jewelryBrand: "Mejuri",
    affirmation: "I am crisp, clear, and unmistakably myself.", avoid: "#D2B48C",
  },
  "True Winter": {
    palette: ["#000000", "#FFFFFF", "#C8102E", "#003153", "#702963", "#1D7874"],
    vibe: "Royal Velvet", emoji: "👑",
    mood: "High-drama and pure — ink black, snow white, ruby red.",
    celebrity: "Lupita Nyong'o", celebReason: "high contrast with deep cool undertones",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX186v583rmzp",
    pinterest: "https://www.pinterest.com/search/pins/?q=true%20winter%20outfit",
    lipstick: { brand: "MAC", name: "Diva", hex: "#8E1B2C" },
    blush: { brand: "NARS", name: "Aroused", hex: "#C84770" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 450", hex: "#704830" },
    clothing: ["#000000", "#FFFFFF", "#C8102E", "#003153", "#702963"],
    jewelry: "Platinum, white gold", jewelryBrand: "Missoma",
    affirmation: "I command the room with quiet brilliance.", avoid: "#F4A460",
  },
  "Dark Winter": {
    palette: ["#0D0D0D", "#3D0C11", "#1A2A40", "#5B2A86", "#0F4C5C", "#9E2A2B"],
    vibe: "Midnight Opera", emoji: "🎭",
    mood: "Deep, glossy and theatrical — jewel tones in low candlelight.",
    celebrity: "Kim Kardashian", celebReason: "deep dark hair with cool olive undertones",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX2pSTOxoPbx9",
    pinterest: "https://www.pinterest.com/search/pins/?q=dark%20winter%20outfit",
    lipstick: { brand: "Fenty", name: "Mattemoiselle Griselda", hex: "#5C1F2C" },
    blush: { brand: "NARS", name: "Dolce Vita", hex: "#A35260" },
    foundation: { brand: "Fenty", name: "Pro Filt'r 490", hex: "#5C3924" },
    clothing: ["#0D0D0D", "#3D0C11", "#1A2A40", "#5B2A86", "#9E2A2B"],
    jewelry: "Polished silver, platinum", jewelryBrand: "Catbird",
    affirmation: "My depth is dramatic and divine.", avoid: "#FFFACD",
  },
  "Soft Autumn": {
    palette: ["#A89F91", "#C2A878", "#8B7355", "#9CAF88", "#B5896A", "#736B5C"],
    vibe: "Sunlit Driftwood", emoji: "🌾",
    mood: "Muted, warm and softly textured — wheat fields at dusk.",
    celebrity: "Scarlett Johansson", celebReason: "muted warm tones with soft contrast",
    spotify: "https://open.spotify.com/playlist/37i9dQZF1DX0jgyAiPl8Af",
    pinterest: "https://www.pinterest.com/search/pins/?q=soft%20autumn%20outfit",
    lipstick: { brand: "Charlotte Tilbury", name: "Stoned Rose", hex: "#B07060" },
    blush: { brand: "Rare Beauty", name: "Encourage", hex: "#C28A75" },
    foundation: { brand: "NARS", name: "Sheer Glow Punjab", hex: "#C8956D" },
    clothing: ["#A89F91", "#C2A878", "#8B7355", "#9CAF88", "#B5896A"],
    jewelry: "Matte gold, antique brass", jewelryBrand: "Mejuri",
    affirmation: "I glow with quiet, layered warmth.", avoid: "#FF1493",
  },
};

export const ALL_SEASONS = Object.keys(SEASONS) as Season[];

export function getSeason(name: string): SeasonData {
  return SEASONS[name] ?? SEASONS["True Spring"];
}
