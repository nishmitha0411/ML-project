// Random Forest classifier for skin undertone (Warm / Cool / Neutral)
// Pure-TS implementation. Trained in-browser at module load on synthetic
// data using 8 features: R, G, B, R-G, R-B, G-B, B-R, ITA.
//
// ITA (Individual Typology Angle) = atan2(L* - 50, b*) * 180 / PI
// is the standard skin-tone descriptor in dermatology.

import type { RGB } from "./analysis";

export type Undertone = "Warm" | "Cool" | "Neutral";
const CLASSES: Undertone[] = ["Warm", "Cool", "Neutral"];

// ---------- Feature extraction ----------
function srgbToLinear(c: number) {
  const x = c / 255;
  return x <= 0.04045 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
}
function rgbToLab(r: number, g: number, b: number): [number, number, number] {
  const R = srgbToLinear(r), G = srgbToLinear(g), B = srgbToLinear(b);
  // sRGB D65 -> XYZ
  const X = (R * 0.4124564 + G * 0.3575761 + B * 0.1804375) / 0.95047;
  const Y = (R * 0.2126729 + G * 0.7151522 + B * 0.0721750) / 1.0;
  const Z = (R * 0.0193339 + G * 0.1191920 + B * 0.9503041) / 1.08883;
  const f = (t: number) => (t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116);
  const fx = f(X), fy = f(Y), fz = f(Z);
  return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
}
export function featuresFromRgb({ r, g, b }: RGB): number[] {
  const [L, , bb] = rgbToLab(r, g, b);
  const ita = (Math.atan2(L - 50, bb) * 180) / Math.PI;
  return [r, g, b, r - g, r - b, g - b, b - r, ita];
}

// ---------- Deterministic PRNG (so training is reproducible) ----------
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- Synthetic training data ----------
// Produces realistic R,G,B samples spanning depth (Light/Medium/Deep)
// for each undertone class, with noise.
function generateTrainingData(rand: () => number) {
  const X: number[][] = [];
  const y: number[] = [];
  const N_PER_CLASS = 250;

  const gauss = () => {
    // Box–Muller
    const u = Math.max(1e-9, rand()), v = rand();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };

  for (let cls = 0; cls < 3; cls++) {
    for (let i = 0; i < N_PER_CLASS; i++) {
      // Base brightness (skin depth) — uniform across Light → Deep
      const base = 70 + rand() * 165; // 70..235
      let r = base, g = base, b = base;
      if (cls === 0) {
        // Warm: red/yellow lean (R high, B lower)
        r = base + 18 + gauss() * 6;
        g = base + 4 + gauss() * 5;
        b = base - 16 + gauss() * 6;
      } else if (cls === 1) {
        // Cool: pink/blue lean (B higher relative to R)
        r = base + 6 + gauss() * 5;
        g = base + 2 + gauss() * 5;
        b = base + 4 + gauss() * 6;
        // ensure cool: lift B a bit more on average
        b += 6;
      } else {
        // Neutral: balanced
        r = base + 8 + gauss() * 5;
        g = base + 4 + gauss() * 5;
        b = base - 2 + gauss() * 5;
      }
      r = Math.max(20, Math.min(250, r));
      g = Math.max(20, Math.min(250, g));
      b = Math.max(20, Math.min(250, b));
      X.push(featuresFromRgb({ r, g, b }));
      y.push(cls);
    }
  }
  return { X, y };
}

// ---------- Decision tree ----------
interface Leaf { leaf: true; probs: number[] }
interface Node { leaf: false; feature: number; threshold: number; left: TreeNode; right: TreeNode }
type TreeNode = Leaf | Node;

function classCounts(y: number[]): number[] {
  const c = [0, 0, 0];
  for (const v of y) c[v]++;
  return c;
}
function gini(counts: number[], total: number): number {
  if (total === 0) return 0;
  let s = 1;
  for (const c of counts) { const p = c / total; s -= p * p; }
  return s;
}
function makeLeaf(y: number[]): Leaf {
  const c = classCounts(y);
  const t = y.length || 1;
  return { leaf: true, probs: c.map((x) => x / t) };
}

function buildTree(
  X: number[][], y: number[], depth: number, maxDepth: number,
  minSamples: number, featuresPerSplit: number, rand: () => number,
): TreeNode {
  if (y.length <= minSamples || depth >= maxDepth) return makeLeaf(y);
  const counts = classCounts(y);
  if (counts.filter((c) => c > 0).length === 1) return makeLeaf(y);

  const nFeat = X[0].length;
  // Random feature subset
  const featIdx: number[] = [];
  const pool = Array.from({ length: nFeat }, (_, i) => i);
  for (let i = 0; i < featuresPerSplit; i++) {
    const j = Math.floor(rand() * pool.length);
    featIdx.push(pool[j]);
    pool.splice(j, 1);
  }

  let bestGain = 0, bestFeat = -1, bestThr = 0;
  const parentImpurity = gini(counts, y.length);

  for (const f of featIdx) {
    // Sample up to 10 candidate thresholds from value distribution
    const vals = X.map((row) => row[f]);
    const sorted = [...vals].sort((a, b) => a - b);
    const candidates: number[] = [];
    for (let k = 1; k <= 8; k++) {
      candidates.push(sorted[Math.floor((sorted.length * k) / 9)]);
    }
    for (const thr of candidates) {
      const lC = [0, 0, 0], rC = [0, 0, 0];
      let lN = 0, rN = 0;
      for (let i = 0; i < y.length; i++) {
        if (X[i][f] <= thr) { lC[y[i]]++; lN++; } else { rC[y[i]]++; rN++; }
      }
      if (lN === 0 || rN === 0) continue;
      const impurity = (lN / y.length) * gini(lC, lN) + (rN / y.length) * gini(rC, rN);
      const gain = parentImpurity - impurity;
      if (gain > bestGain) { bestGain = gain; bestFeat = f; bestThr = thr; }
    }
  }

  if (bestFeat < 0) return makeLeaf(y);

  const lX: number[][] = [], lY: number[] = [], rX: number[][] = [], rY: number[] = [];
  for (let i = 0; i < y.length; i++) {
    if (X[i][bestFeat] <= bestThr) { lX.push(X[i]); lY.push(y[i]); }
    else { rX.push(X[i]); rY.push(y[i]); }
  }
  return {
    leaf: false,
    feature: bestFeat,
    threshold: bestThr,
    left: buildTree(lX, lY, depth + 1, maxDepth, minSamples, featuresPerSplit, rand),
    right: buildTree(rX, rY, depth + 1, maxDepth, minSamples, featuresPerSplit, rand),
  };
}

function predictTree(tree: TreeNode, x: number[]): number[] {
  let n: TreeNode = tree;
  while (!n.leaf) n = x[n.feature] <= n.threshold ? n.left : n.right;
  return n.probs;
}

// ---------- Forest ----------
const N_TREES = 25;
const MAX_DEPTH = 9;
const MIN_SAMPLES = 4;
const FEATURES_PER_SPLIT = 3; // sqrt(8) ≈ 3

let FOREST: TreeNode[] | null = null;

function trainForest(): TreeNode[] {
  const rand = mulberry32(20260603);
  const { X, y } = generateTrainingData(rand);
  const trees: TreeNode[] = [];
  for (let t = 0; t < N_TREES; t++) {
    // Bootstrap sample
    const bX: number[][] = [], bY: number[] = [];
    for (let i = 0; i < X.length; i++) {
      const idx = Math.floor(rand() * X.length);
      bX.push(X[idx]); bY.push(y[idx]);
    }
    trees.push(buildTree(bX, bY, 0, MAX_DEPTH, MIN_SAMPLES, FEATURES_PER_SPLIT, rand));
  }
  return trees;
}

function ensureForest(): TreeNode[] {
  if (!FOREST) FOREST = trainForest();
  return FOREST;
}

export interface UndertonePrediction {
  label: Undertone;
  probs: { Warm: number; Cool: number; Neutral: number };
  confidence: number; // 0..1, top class probability
}

export function predictUndertone(skin: RGB): UndertonePrediction {
  const trees = ensureForest();
  const x = featuresFromRgb(skin);
  const agg = [0, 0, 0];
  for (const t of trees) {
    const p = predictTree(t, x);
    for (let i = 0; i < 3; i++) agg[i] += p[i];
  }
  for (let i = 0; i < 3; i++) agg[i] /= trees.length;
  let best = 0;
  for (let i = 1; i < 3; i++) if (agg[i] > agg[best]) best = i;
  return {
    label: CLASSES[best],
    probs: { Warm: agg[0], Cool: agg[1], Neutral: agg[2] },
    confidence: agg[best],
  };
}

// Eager warm-up in the browser so the first prediction is instant.
if (typeof window !== "undefined") {
  setTimeout(() => { ensureForest(); }, 0);
}
