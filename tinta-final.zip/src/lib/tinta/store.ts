import { create, type StateCreator } from "zustand";
import { persist, type PersistOptions } from "zustand/middleware";
import type { AnalysisResult } from "./analysis";

export interface DiaryEntry {
  id: string;
  createdAt: number;
  result: AnalysisResult;
  /** Small JPEG data URL captured at analysis time (no original image kept). */
  thumbnail?: string;
  note?: string;
}

interface TintaState {
  dark: boolean;
  toggleDark: () => void;
  setDark: (v: boolean) => void;
  current: AnalysisResult | null;
  currentThumbnail: string | null;
  setCurrent: (r: AnalysisResult | null, thumbnail?: string | null) => void;
  diary: DiaryEntry[];
  saveCurrent: () => void;
  deleteEntry: (id: string) => void;
}

// IMPORTANT: keep the initial value deterministic & identical on server and
// client. Reading prefers-color-scheme or localStorage at module init causes
// hydration mismatches that React refuses to patch up (which manifests as
// broken layout / Switch state). The persisted value is rehydrated on the
// client *after* mount via the effect in __root.tsx.
const creator: StateCreator<TintaState> = (set, get) => ({
  dark: false,
  toggleDark: () => set({ dark: !get().dark }),
  setDark: (v: boolean) => set({ dark: v }),
  current: null,
  currentThumbnail: null,
  setCurrent: (r: AnalysisResult | null, thumbnail?: string | null) =>
    set({ current: r, currentThumbnail: thumbnail ?? (r ? get().currentThumbnail : null) }),
  diary: [],
  saveCurrent: () => {
    const r = get().current;
    if (!r) return;
    const entry: DiaryEntry = {
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      result: r,
      thumbnail: get().currentThumbnail ?? undefined,
    };
    set({ diary: [entry, ...get().diary] });
  },
  deleteEntry: (id: string) =>
    set({ diary: get().diary.filter((e: DiaryEntry) => e.id !== id) }),
});

const persistOpts: PersistOptions<TintaState, Pick<TintaState, "dark" | "diary">> = {
  name: "tinta-store",
  partialize: (s) => ({ dark: s.dark, diary: s.diary }),
  // Skip hydration on import; we trigger it explicitly from a client effect.
  skipHydration: true,
};

export const useTinta = create<TintaState>()(persist(creator, persistOpts));
