import { create, type StateCreator } from "zustand";
import { persist, type PersistOptions } from "zustand/middleware";
import type { AnalysisResult } from "./analysis";

export interface DiaryEntry {
  id: string;
  createdAt: number;
  result: AnalysisResult;
  /** Small JPEG data URL captured at analysis time (no original image kept). */
  thumbnail?: string;
  note?: string;
}

interface TintaState {
  dark: boolean;
  toggleDark: () => void;
  setDark: (v: boolean) => void;
  current: AnalysisResult | null;
  currentThumbnail: string | null;
  setCurrent: (r: AnalysisResult | null, thumbnail?: string | null) => void;
  diary: DiaryEntry[];
  saveCurrent: () => void;
  deleteEntry: (id: string) => void;
}

const prefersDark =
  typeof window !== "undefined" &&
  window.matchMedia?.("(prefers-color-scheme: dark)").matches;

const creator: StateCreator<TintaState> = (set, get) => ({
  dark: prefersDark ?? false,
  toggleDark: () => set({ dark: !get().dark }),
  setDark: (v: boolean) => set({ dark: v }),
  current: null,
  currentThumbnail: null,
  setCurrent: (r: AnalysisResult | null, thumbnail?: string | null) =>
    set({ current: r, currentThumbnail: thumbnail ?? (r ? get().currentThumbnail : null) }),
  diary: [],
  saveCurrent: () => {
    const r = get().current;
    if (!r) return;
    const entry: DiaryEntry = {
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      result: r,
      thumbnail: get().currentThumbnail ?? undefined,
    };
    set({ diary: [entry, ...get().diary] });
  },
  deleteEntry: (id: string) =>
    set({ diary: get().diary.filter((e: DiaryEntry) => e.id !== id) }),
});

const persistOpts: PersistOptions<TintaState, Pick<TintaState, "dark" | "diary">> = {
  name: "tinta-store",
  partialize: (s) => ({ dark: s.dark, diary: s.diary }),
};

export const useTinta = create<TintaState>()(persist(creator, persistOpts));

if (typeof window !== "undefined") {
  useTinta.subscribe((s) => {
    document.documentElement.classList.toggle("dark", s.dark);
  });
  setTimeout(() => {
    document.documentElement.classList.toggle("dark", useTinta.getState().dark);
  }, 0);
}
