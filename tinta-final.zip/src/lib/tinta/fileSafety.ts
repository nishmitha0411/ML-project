// Client-side photo safety. Photos never leave the device.
//
// Validates magic bytes (not just MIME), enforces a sensible size cap,
// and re-encodes through a canvas to strip EXIF / GPS / camera metadata
// before the image is shown or analyzed.

export const MAX_PHOTO_BYTES = 15 * 1024 * 1024; // 15 MB

const SIGNATURES: Array<{ mime: string; bytes: number[] }> = [
  { mime: "image/jpeg", bytes: [0xff, 0xd8, 0xff] },
  { mime: "image/png", bytes: [0x89, 0x50, 0x4e, 0x47] },
  { mime: "image/webp", bytes: [0x52, 0x49, 0x46, 0x46] }, // RIFF (WEBP container)
];

export async function detectMimeFromMagic(file: File): Promise<string | null> {
  const head = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  for (const sig of SIGNATURES) {
    if (sig.bytes.every((b, i) => head[i] === b)) return sig.mime;
  }
  return null;
}

export interface SafePhoto {
  file: File;       // re-encoded JPEG, EXIF-free
  previewUrl: string;
}

/**
 * Validates a user-supplied photo and returns a sanitized copy.
 * Throws a user-readable error on any failure.
 */
export async function sanitizePhoto(input: File): Promise<SafePhoto> {
  if (!input) throw new Error("No file provided.");
  if (input.size > MAX_PHOTO_BYTES) {
    throw new Error(`Photo is too large. Maximum is ${Math.round(MAX_PHOTO_BYTES / 1024 / 1024)} MB.`);
  }
  if (input.size === 0) throw new Error("Photo is empty.");
  const magic = await detectMimeFromMagic(input);
  if (!magic) throw new Error("Unsupported file. Please use a JPG, PNG, or WEBP photo.");

  const url = URL.createObjectURL(input);
  let img: HTMLImageElement;
  try {
    img = await loadImage(url);
  } finally {
    URL.revokeObjectURL(url);
  }

  // Cap dimensions while re-encoding (also strips EXIF).
  const MAX_SIDE = 1600;
  const scale = Math.min(1, MAX_SIDE / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas not available in this browser.");
  ctx.drawImage(img, 0, 0, w, h);

  const blob: Blob = await new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Could not process photo."))), "image/jpeg", 0.92),
  );
  const cleanFile = new File([blob], "photo.jpg", { type: "image/jpeg" });
  return { file: cleanFile, previewUrl: URL.createObjectURL(cleanFile) };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read this image."));
    img.src = src;
  });
}
