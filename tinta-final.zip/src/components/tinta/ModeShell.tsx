import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

export function ModeShell({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  return (
    <div className="mode-shell">
      <Link to="/analyze" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition mb-6">
        <ArrowLeft className="h-4 w-4" /> All methods
      </Link>
      <div className="mb-8 fade-slide-in">
        <h1 className="font-display text-3xl md:text-4xl text-secondary dark:text-foreground">{title}</h1>
        <p className="text-muted-foreground mt-2">{subtitle}</p>
      </div>
      <div className="mode-panel neomorph rounded-3xl p-6 md:p-8 fade-slide-in stagger-1">{children}</div>
    </div>
  );
}

export function LoadingShimmer({ label = "Analyzing your colors…" }: { label?: string }) {
  return (
    <div className="text-center py-10">
      <div className="inline-block h-12 w-12 rounded-full border-4 border-primary/20 border-t-primary animate-spin mb-4" />
      <div className="font-display text-lg">{label}</div>
      <div className="text-xs text-muted-foreground mt-1">Reading your undertone, depth, contrast…</div>
      <div className="h-2 rounded-full mt-6 max-w-xs mx-auto shimmer" />
    </div>
  );
}
