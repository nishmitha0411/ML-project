import { Link, useNavigate } from "@tanstack/react-router";
import { useTinta } from "@/lib/tinta/store";
import { getSeason } from "@/lib/tinta/seasons";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  ArrowLeft, ArrowRight, Download, Mail, Copy, BookmarkPlus, Sparkles,
  ExternalLink, Music, Heart, Shirt,
} from "lucide-react";
import { useState, useMemo } from "react";
import { rgbToHex } from "@/lib/tinta/analysis";
import { ALL_SEASONS } from "@/lib/tinta/seasons";
import { toast } from "sonner";
import { buildReportPdf } from "@/lib/tinta/pdfReport";

function Swatch({ color, label }: { color: string; label?: string }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className="h-12 w-12 rounded-xl shadow-md ring-1 ring-black/5 transition-transform hover:scale-110"
        style={{ background: color }}
      />
      <span className="text-[10px] font-mono text-muted-foreground uppercase">{label ?? color}</span>
    </div>
  );
}

function CircularConfidence({ value }: { value: number }) {
  const r = 36, c = 2 * Math.PI * r;
  const dash = (value / 100) * c;
  return (
    <div className="relative h-24 w-24">
      <svg className="-rotate-90" viewBox="0 0 88 88" width="96" height="96">
        <circle cx="44" cy="44" r={r} className="fill-none stroke-muted" strokeWidth="8" />
        <circle
          cx="44" cy="44" r={r}
          className="fill-none stroke-primary transition-all duration-700"
          strokeWidth="8" strokeLinecap="round"
          strokeDasharray={`${dash} ${c}`}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="font-display text-2xl font-bold text-secondary dark:text-foreground">{value}%</div>
          <div className="text-[9px] uppercase tracking-wider text-muted-foreground">match</div>
        </div>
      </div>
    </div>
  );
}

export function ResultsView() {
  const { current, saveCurrent } = useTinta();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [whatIfHair, setWhatIfHair] = useState("Same");
  const [email, setEmail] = useState("");
  const [emailErr, setEmailErr] = useState("");

  const s = current ? getSeason(current.season) : null;

  const harmonies = useMemo(() => {
    if (!s) return { complementary: [], analogous: [], triadic: [] };
    return {
      complementary: [s.palette[0], s.palette[3]],
      analogous: [s.palette[0], s.palette[1], s.palette[2]],
      triadic: [s.palette[0], s.palette[2], s.palette[4]],
    };
  }, [s]);

  const whatIfSeason = useMemo(() => {
    if (!current) return "";
    if (whatIfHair === "Same") return current.season;
    if (whatIfHair === "Platinum Blonde") return current.undertone === "Cool" ? "Light Summer" : "Light Spring";
    if (whatIfHair === "Jet Black") return current.undertone === "Cool" ? "True Winter" : "Deep Autumn";
    if (whatIfHair === "Copper Red") return "True Spring";
    if (whatIfHair === "Ash Brown") return "Soft Summer";
    return current.season;
  }, [whatIfHair, current]);

  if (!current || !s) {
    return (
      <div className="p-12 text-center">
        <p className="text-muted-foreground mb-4">No analysis yet.</p>
        <Button asChild><Link to="/analyze">Start an analysis</Link></Button>
      </div>
    );
  }

  const copyResults = () => {
    const text = `My Tinta Color Analysis\nSeason: ${current.season}\nUndertone: ${current.undertone}\nDepth: ${current.depth}\nConfidence: ${current.confidence}%\nPalette: ${s.palette.join(", ")}`;
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const downloadAffirmation = () => {
    const c = document.createElement("canvas");
    c.width = 1080; c.height = 1080;
    const ctx = c.getContext("2d")!;
    const grad = ctx.createLinearGradient(0, 0, 1080, 1080);
    grad.addColorStop(0, s.palette[0]);
    grad.addColorStop(1, s.palette[3]);
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 1080, 1080);
    ctx.fillStyle = "rgba(0,0,0,0.45)"; ctx.fillRect(0, 0, 1080, 1080);
    ctx.fillStyle = "#F5EFE6"; ctx.textAlign = "center";
    ctx.font = "bold 64px Georgia"; ctx.fillText(current.season, 540, 380);
    ctx.font = "italic 36px Georgia"; ctx.fillText(`"${s.affirmation}"`, 540, 480);
    ctx.font = "28px sans-serif"; ctx.fillText(s.vibe, 540, 560);
    s.palette.forEach((col, i) => {
      ctx.fillStyle = col;
      ctx.fillRect(140 + i * 130, 680, 110, 110);
    });
    ctx.fillStyle = "#F5EFE6"; ctx.font = "24px sans-serif";
    ctx.fillText("✦ Tinta · Personal Color Atelier ✦", 540, 980);
    const a = document.createElement("a");
    a.href = c.toDataURL("image/png");
    a.download = `tinta-${current.season.replace(/\s/g, "-")}.png`;
    a.click();
    toast.success("Affirmation card downloaded");
  };

  const downloadPDF = () => {
    const skinHex = (current as any).skinHex || s.foundation.hex;
    const doc = buildReportPdf({ ...current, skinHex }, s);
    doc.save(`tinta-${current.season.replace(/\s/g, "-").toLowerCase()}.pdf`);
  };

  const submitEmail = () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setEmailErr("Enter a valid email"); return; }
    setEmailErr("");
    toast.success(`Demo: report would be sent to ${email}`);
  };

  return (
    <div className="max-w-5xl mx-auto p-6 md:p-10">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 fade-slide-in">
        <div>
          <div className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">Your Result</div>
          <h1 className="font-display text-3xl md:text-4xl text-secondary dark:text-foreground mt-1">
            {current.season} {s.emoji}
          </h1>
        </div>
        <div className="flex gap-2 text-xs">
          {[0, 1, 2].map((i) => (
            <div key={i} className={`h-2 rounded-full transition-all ${step === i ? "w-8 bg-primary" : "w-2 bg-muted"}`} />
          ))}
        </div>
      </div>

      {/* Cards */}
      {step === 0 && <Card1 s={s} current={current} confidence={current.confidence} harmony={current.harmony} harmonies={harmonies} />}
      {step === 1 && <Card2 s={s} whatIfHair={whatIfHair} setWhatIfHair={setWhatIfHair} whatIfSeason={whatIfSeason} />}
      {step === 2 && (
        <Card3
          onCopy={copyResults}
          onAffirmation={downloadAffirmation}
          onPDF={downloadPDF}
          onSave={() => { saveCurrent(); toast.success("Saved to Color Diary"); }}
          email={email} setEmail={setEmail} emailErr={emailErr} submitEmail={submitEmail}
          onNew={() => navigate({ to: "/analyze" })}
        />
      )}

      {/* Nav */}
      <div className="flex items-center justify-between mt-8">
        <Button
          variant="outline"
          className="pill-btn"
          onClick={() => setStep(Math.max(0, step - 1))}
          disabled={step === 0}
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <Button
          className="pill-btn bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={() => setStep(Math.min(2, step + 1))}
          disabled={step === 2}
        >
          Next <ArrowRight className="h-4 w-4 ml-1" />
        </Button>
      </div>
    </div>
  );
}

function Card1({ s, current, confidence, harmony, harmonies }: any) {
  return (
    <div className="neomorph rounded-3xl p-6 md:p-8 fade-slide-in space-y-6">
      <div className="grid md:grid-cols-[auto_1fr_auto] gap-6 items-center">
        <CircularConfidence value={confidence} />
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/20 text-accent text-xs font-semibold uppercase tracking-wider mb-2">
            {current.undertone} · {current.depth}
          </div>
          <p className="text-2xl font-display text-secondary dark:text-foreground">{s.vibe}</p>
          <p className="text-sm text-muted-foreground mt-1">{s.mood}</p>
        </div>
        <div className="text-center">
          <div className="font-display text-3xl text-primary">{harmony}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Harmony</div>
        </div>
      </div>

      <div>
        <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Signature Palette</h4>
        <div className="flex flex-wrap gap-4">
          {s.palette.map((c: string) => <Swatch key={c} color={c} />)}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Top Season Matches</h4>
          <div className="space-y-2">
            {current.probabilities.map((p: any) => (
              <div key={p.season}>
                <div className="flex justify-between text-xs mb-1"><span>{p.season}</span><span className="font-mono">{p.pct}%</span></div>
                <Progress value={p.pct} className="h-2" />
              </div>
            ))}
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-muted/50">
            <Heart className="h-4 w-4 text-accent mt-0.5" />
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Celebrity Twin · 87% match</div>
              <div className="font-display text-lg">{s.celebrity}</div>
              <div className="text-xs text-muted-foreground">{s.celebReason}</div>
            </div>
          </div>
          <div className="flex gap-2">
            <a href={s.spotify} target="_blank" rel="noreferrer" className="flex-1 flex items-center gap-2 px-3 py-2 rounded-xl bg-secondary text-secondary-foreground text-xs hover:opacity-90 transition">
              <Music className="h-4 w-4" /> Playlist <ExternalLink className="h-3 w-3 ml-auto" />
            </a>
            <a href={s.pinterest} target="_blank" rel="noreferrer" className="flex-1 flex items-center gap-2 px-3 py-2 rounded-xl bg-accent text-accent-foreground text-xs hover:opacity-90 transition">
              <Sparkles className="h-4 w-4" /> Pinterest <ExternalLink className="h-3 w-3 ml-auto" />
            </a>
          </div>
        </div>
      </div>

      <div>
        <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Color Harmonies</h4>
        <div className="grid grid-cols-3 gap-3 text-center text-xs">
          {(["complementary", "analogous", "triadic"] as const).map((k) => (
            <div key={k} className="p-3 rounded-xl border border-border">
              <div className="font-semibold capitalize mb-2">{k}</div>
              <div className="flex justify-center gap-1">
                {harmonies[k].map((c: string) => (
                  <div key={c} className="h-8 w-8 rounded-md" style={{ background: c }} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Card2({ s, whatIfHair, setWhatIfHair, whatIfSeason }: any) {
  const best = s.palette[0];
  return (
    <div className="neomorph rounded-3xl p-6 md:p-8 fade-slide-in space-y-6">
      <h3 className="font-display text-2xl text-secondary dark:text-foreground">Curated Recommendations</h3>

      <div>
        <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Makeup</h4>
        <div className="grid sm:grid-cols-3 gap-3">
          {[s.lipstick, s.blush, s.foundation].map((m, i) => (
            <div key={i} className="p-4 rounded-xl bg-muted/40 border border-border">
              <div className="h-12 rounded-lg mb-2" style={{ background: m.hex }} />
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{["Lipstick", "Blush", "Foundation"][i]}</div>
              <div className="text-sm font-semibold">{m.brand}</div>
              <div className="text-xs text-muted-foreground">{m.name}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl border border-border">
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Best vs Avoid</h4>
          <div className="flex gap-3 items-center">
            <div className="flex-1 text-center">
              <div className="h-24 rounded-xl shadow-lg" style={{ background: best }} />
              <div className="text-xs mt-2 text-primary font-semibold">BEST · {best}</div>
            </div>
            <div className="text-2xl text-muted-foreground">vs</div>
            <div className="flex-1 text-center">
              <div className="h-24 rounded-xl opacity-60" style={{ background: s.avoid }} />
              <div className="text-xs mt-2 text-destructive font-semibold">AVOID · {s.avoid}</div>
            </div>
          </div>
        </div>
        <div className="p-4 rounded-xl border border-border">
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-3 flex items-center gap-2">
            <Shirt className="h-3 w-3" /> Clothing Edit
          </h4>
          <div className="flex flex-wrap gap-2">
            {s.clothing.map((c: string) => (
              <span key={c} className="px-3 py-1.5 rounded-full text-xs font-medium text-white shadow-sm transition-transform hover:scale-105"
                    style={{ background: c }}>{c}</span>
            ))}
          </div>
          <div className="text-xs text-muted-foreground mt-3">Shop: COS · Aritzia · & Other Stories</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl border border-border">
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Jewelry</h4>
          <p className="text-sm">{s.jewelry}</p>
          <p className="text-xs text-muted-foreground mt-1">Try: {s.jewelryBrand}</p>
        </div>
        <div className="p-4 rounded-xl border border-border">
          <h4 className="text-xs uppercase tracking-widest text-muted-foreground mb-2">"What If" Hair Simulator</h4>
          <select
            value={whatIfHair} onChange={(e) => setWhatIfHair(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm"
          >
            {["Same", "Platinum Blonde", "Ash Brown", "Copper Red", "Jet Black"].map((h) =>
              <option key={h}>{h}</option>)}
          </select>
          <p className="text-xs mt-2">→ would shift you toward <span className="font-semibold text-primary">{whatIfSeason}</span></p>
        </div>
      </div>
    </div>
  );
}

function Card3({ onCopy, onAffirmation, onPDF, onSave, email, setEmail, emailErr, submitEmail, onNew }: any) {
  return (
    <div className="neomorph rounded-3xl p-6 md:p-8 fade-slide-in space-y-5">
      <h3 className="font-display text-2xl text-secondary dark:text-foreground">Keep · Share · Begin Again</h3>

      <div className="grid sm:grid-cols-2 gap-3">
        <button onClick={onAffirmation} className="p-4 rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground text-left transition-transform hover:scale-[1.02]">
          <Sparkles className="h-5 w-5 mb-2" />
          <div className="font-semibold">Affirmation Card</div>
          <div className="text-xs opacity-80">Downloadable 1080×1080 image</div>
        </button>
        <button onClick={onPDF} className="p-4 rounded-xl bg-secondary text-secondary-foreground text-left transition-transform hover:scale-[1.02]">
          <Download className="h-5 w-5 mb-2" />
          <div className="font-semibold">Full PDF Report</div>
          <div className="text-xs opacity-80">Style guide · palette · brands</div>
        </button>
        <button onClick={onCopy} className="p-4 rounded-xl border border-border text-left transition-transform hover:scale-[1.02]">
          <Copy className="h-5 w-5 mb-2 text-primary" />
          <div className="font-semibold">Copy Results</div>
          <div className="text-xs text-muted-foreground">Plain text to clipboard</div>
        </button>
        <button onClick={onSave} className="p-4 rounded-xl border border-border text-left transition-transform hover:scale-[1.02]">
          <BookmarkPlus className="h-5 w-5 mb-2 text-accent" />
          <div className="font-semibold">Save to Diary</div>
          <div className="text-xs text-muted-foreground">Build your color archive</div>
        </button>
      </div>

      <div className="p-4 rounded-xl border border-border">
        <label className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-2 mb-2">
          <Mail className="h-3 w-3" /> Email me the full report
        </label>
        <div className="flex gap-2">
          <input
            type="email" value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            className="flex-1 px-3 py-2 rounded-lg border border-border bg-background text-sm"
          />
          <Button onClick={submitEmail} className="pill-btn bg-primary text-primary-foreground hover:bg-primary/90">Send</Button>
        </div>
        {emailErr && <div className="text-xs text-destructive mt-1">{emailErr}</div>}
      </div>

      <Button onClick={onNew} variant="outline" className="w-full pill-btn">
        ✦ Begin Another Analysis
      </Button>
    </div>
  );
}
