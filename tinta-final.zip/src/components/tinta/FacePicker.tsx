import { useEffect, useRef } from "react";
import type { FaceBox } from "@/lib/tinta/faceDetect";

interface Props {
  previewUrl: string;
  imgW: number;
  imgH: number;
  faces: FaceBox[];
  onPick: (face: FaceBox) => void;
  onCancel: () => void;
}

/**
 * Shown when more than one human face is detected in the photo.
 * The user taps the face they want analysed.
 */
export function FacePicker({ previewUrl, imgW, imgH, faces, onPick, onCancel }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const img = new Image();
    img.onload = () => {
      const maxW = Math.min(640, canvas.parentElement?.clientWidth ?? 480);
      const scale = maxW / imgW;
      canvas.width = imgW * scale;
      canvas.height = imgH * scale;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    };
    img.src = previewUrl;
  }, [previewUrl, imgW, imgH]);

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur p-4 grid place-items-center">
      <div className="bg-card border border-border rounded-2xl shadow-2xl max-w-xl w-full p-5">
        <div className="font-display text-xl mb-1">Multiple faces detected</div>
        <p className="text-sm text-muted-foreground mb-4">
          Tap the face you want analysed.
        </p>
        <div className="relative inline-block max-w-full">
          <canvas ref={canvasRef} className="rounded-xl border border-border max-w-full h-auto block" />
          {faces.map((f, i) => {
            const canvas = canvasRef.current;
            const scale = canvas ? canvas.width / imgW : 1;
            return (
              <button
                key={i}
                onClick={() => onPick(f)}
                className="absolute border-2 border-primary rounded-md hover:bg-primary/20 transition"
                style={{
                  left: f.x * scale,
                  top: f.y * scale,
                  width: f.width * scale,
                  height: f.height * scale,
                }}
                aria-label={`Pick face ${i + 1}`}
              >
                <span className="absolute -top-6 left-0 bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded">
                  Face {i + 1}
                </span>
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex justify-end">
          <button
            onClick={onCancel}
            className="text-sm text-muted-foreground hover:text-foreground px-3 py-1.5 rounded"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
