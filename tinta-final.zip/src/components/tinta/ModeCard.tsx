import { Link } from "@tanstack/react-router";
import { ArrowRight, type LucideIcon } from "lucide-react";

interface ModeCardProps {
  to: string;
  icon: LucideIcon;
  title: string;
  description: string;
  accent?: "primary" | "accent";
  delayClass?: string;
}

export function ModeCard({ to, icon: Icon, title, description, accent = "primary", delayClass = "" }: ModeCardProps) {
  return (
    <Link
      to={to}
      className={`group fade-slide-in ${delayClass} neomorph neomorph-hover rounded-2xl p-6 flex flex-col gap-4 relative overflow-hidden`}
    >
      <div className="absolute inset-x-0 top-0 h-1 gold-gradient opacity-70" />
      <div className={`grid h-12 w-12 place-items-center rounded-xl ${accent === "primary" ? "bg-primary/15 text-primary" : "bg-accent/20 text-accent"}`}>
        <Icon className="h-6 w-6" />
      </div>
      <div className="flex-1">
        <h3 className="font-display text-xl font-semibold text-secondary dark:text-foreground">{title}</h3>
        <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{description}</p>
      </div>
      <div className="flex items-center gap-1 text-primary text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
        Begin <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}
