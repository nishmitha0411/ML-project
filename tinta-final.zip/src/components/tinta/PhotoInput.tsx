import { useEffect, useRef, useState } from "react";
import { Upload, Camera, X, ShieldCheck, RotateCcw, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { sanitizePhoto, MAX_PHOTO_BYTES } from "@/lib/tinta/fileSafety";
import { preloadFaceModel } from "@/lib/tinta/faceDetect";

interface Props {
  /** Called with a sanitized, EXIF-stripped File whenever the user picks/captures a photo. */
  onPhoto: (file: File, previewUrl: string) => void;
  /** Existing preview URL, if any. */
  previewUrl?: string | null;
  /** Optional label text. */
  label?: string;
  /** Compact variant (smaller padding). */
  compact?: boolean;
}

type Mode = "idle" | "camera";

export function PhotoInput({ onPhoto, previewUrl, label, compact }: Props) {
  const [mode, setMode] = useState<Mode>("idle");
  const [error, setError] = useState("");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Warm the face-detection model so the first analysis isn't slow.
  useEffect(() => {
    preloadFaceModel();
  }, []);

  // Camera lifecycle.
  useEffect(() => {
    if (mode !== "camera") {
      stopCamera();
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
      } catch (e) {
        setError(
          e instanceof Error && e.name === "NotAllowedError"
            ? "Camera permission denied. Allow camera access or use Upload."
            : "Couldn't access the camera on this device.",
        );
        setMode("idle");
      }
    })();
    return () => {
      cancelled = true;
      stopCamera();
    };
  }, [mode, facing]);

  function stopCamera() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  }

  async function handleFile(file: File | undefined | null) {
    setError("");
    if (!file) return;
    try {
      const { file: clean, previewUrl: url } = await sanitizePhoto(file);
      onPhoto(clean, url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not read this photo.");
    }
  }

  async function capture() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    // Front camera is mirrored in preview — un-mirror for sampling.
    if (facing === "user") {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, 0, 0);
    const blob: Blob | null = await new Promise((res) => canvas.toBlob((b) => res(b), "image/jpeg", 0.92));
    if (!blob) {
      setError("Couldn't capture frame.");
      return;
    }
    const file = new File([blob], "capture.jpg", { type: "image/jpeg" });
    setMode("idle");
    handleFile(file);
  }

  const pad = compact ? "p-4" : "p-8";

  if (mode === "camera") {
    return (
      <div className="space-y-3">
        <div className="relative rounded-2xl overflow-hidden border border-border bg-black">
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full max-h-[420px] object-cover"
            style={{ transform: facing === "user" ? "scaleX(-1)" : undefined }}
          />
          <button
            type="button"
            onClick={() => setMode("idle")}
            className="absolute top-2 right-2 bg-background/80 rounded-full p-1.5"
            aria-label="Close camera"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="flex gap-2">
          <Button onClick={capture} className="flex-1 pill-btn bg-primary text-primary-foreground hover:bg-primary/90">
            Capture
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => setFacing((f) => (f === "user" ? "environment" : "user"))}
            className="pill-btn"
            aria-label="Switch camera"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
        <PrivacyNote />
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <label
        className={`photo-dropzone relative block overflow-hidden border-2 border-dashed border-border rounded-2xl ${pad} text-center cursor-pointer hover:border-primary transition`}
      >
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0"
          onChange={(e) => {
            void handleFile(e.target.files?.[0]);
            e.currentTarget.value = "";
          }}
        />
        {previewUrl ? (
          <img src={previewUrl} alt="preview" className="mx-auto rounded-xl max-h-72 object-cover" />
        ) : (
          <>
            <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
            <div className="text-sm font-semibold">{label ?? "Click to upload a photo"}</div>
            <div className="text-xs text-muted-foreground mt-1">
              JPG, PNG, or WEBP · up to {Math.round(MAX_PHOTO_BYTES / 1024 / 1024)} MB
            </div>
          </>
        )}
      </label>

      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => setMode("camera")}
          className="pill-btn flex-1"
        >
          <Camera className="h-4 w-4 mr-2" /> Use camera instead
        </Button>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" /> {error}
        </div>
      )}

      <PrivacyNote />
    </div>
  );
}

function PrivacyNote() {
  return (
    <p className="flex items-start gap-1.5 text-xs text-muted-foreground">
      <ShieldCheck className="h-3.5 w-3.5 mt-0.5 text-primary shrink-0" />
      Your photo is processed entirely on this device. Nothing is uploaded, stored on a server, or shared.
    </p>
  );
}
