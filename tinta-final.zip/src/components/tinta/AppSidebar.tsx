import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Sparkles, BookHeart, Trash2, Palette, ShieldCheck } from "lucide-react";

import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { Switch } from "@/components/ui/switch";
import { useTinta, type DiaryEntry } from "@/lib/tinta/store";
import { getSeason } from "@/lib/tinta/seasons";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const items = [
  { title: "Home", url: "/", icon: Home },
  { title: "New Analysis", url: "/analyze", icon: Sparkles },
  { title: "Color Diary", url: "/diary", icon: BookHeart },
  { title: "Privacy", url: "/privacy", icon: ShieldCheck },
];


export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const path = useRouterState({ select: (r) => r.location.pathname });
  const { dark, toggleDark, diary, deleteEntry } = useTinta();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <Link to="/" className="flex items-center gap-2 px-2 py-3">
          <div className="grid h-9 w-9 place-items-center rounded-xl gold-gradient shadow-md">
            <Palette className="h-5 w-5 text-secondary" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="font-display text-xl font-bold text-sidebar-foreground">Tinta</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                Color · Atelier
              </span>
            </div>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigate</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => {
                const active = item.url === "/" ? path === "/" : path.startsWith(item.url);
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={active}
                      className={
                        active
                          ? "bg-primary/15 text-primary font-semibold border-l-2 border-primary"
                          : ""
                      }
                    >
                      <Link to={item.url} className="flex items-center gap-3">
                        <item.icon className="h-4 w-4" />
                        {!collapsed && <span>{item.title}</span>}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {!collapsed && diary.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel>Saved Entries</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {diary.slice(0, 6).map((e: DiaryEntry) => {
                  const s = getSeason(e.result.season);
                  return (
                    <SidebarMenuItem key={e.id}>
                      <div className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-md hover:bg-sidebar-accent text-xs">
                        <div className="flex items-center gap-2 min-w-0">
                          {e.thumbnail ? (
                            <img src={e.thumbnail} alt="" className="h-6 w-6 rounded-full object-cover ring-1 ring-border" />
                          ) : (
                            <span className="text-base">{s.emoji}</span>
                          )}
                          <span className="truncate">{e.result.season}</span>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>

                            <button className="opacity-60 hover:opacity-100 hover:text-destructive transition">
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete this entry?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Remove your {e.result.season} analysis from the Color Diary. This cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteEntry(e.id)}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <div className="flex items-center justify-between px-2 py-3">
          {!collapsed && <span className="text-xs text-muted-foreground">Theme</span>}
          <Switch checked={dark} onCheckedChange={toggleDark} aria-label="Toggle dark mode" />
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
