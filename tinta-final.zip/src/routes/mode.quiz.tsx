import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ModeShell } from "@/components/tinta/ModeShell";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { analyze, hexToRgb } from "@/lib/tinta/analysis";
import { useTinta } from "@/lib/tinta/store";
import { ArrowLeft, ArrowRight } from "lucide-react";

interface Q { q: string; opts: { label: string; tag: "warm" | "cool" | "neutral"; depth?: "L" | "M" | "D" }[]; }

const QUESTIONS: Q[] = [
  { q: "Look at the veins on your inner wrist — they appear:", opts: [
    { label: "Greenish", tag: "warm" }, { label: "Blue or purple", tag: "cool" }, { label: "A mix of both", tag: "neutral" }] },
  { q: "Which metal flatters your skin most?", opts: [
    { label: "Yellow gold", tag: "warm" }, { label: "Silver / platinum", tag: "cool" }, { label: "Rose gold — either", tag: "neutral" }] },
  { q: "How does your skin react to sun?", opts: [
    { label: "Tans easily, rarely burns", tag: "warm" }, { label: "Burns first, tans little", tag: "cool" }, { label: "Tans gradually", tag: "neutral" }] },
  { q: "Which white looks best on you?", opts: [
    { label: "Ivory / cream", tag: "warm" }, { label: "Pure bright white", tag: "cool" }, { label: "Either works", tag: "neutral" }] },
  { q: "Your most flattering lipstick is:", opts: [
    { label: "Coral, peach, terracotta", tag: "warm" }, { label: "Berry, plum, blue-red", tag: "cool" }, { label: "Mauve, rose-nude", tag: "neutral" }] },
  { q: "Your natural hair color is closest to:", opts: [
    { label: "Light blonde / red", tag: "warm", depth: "L" }, { label: "Medium brown / auburn", tag: "warm", depth: "M" },
    { label: "Ash blonde / cool brown", tag: "cool", depth: "M" }, { label: "Jet black / very dark", tag: "cool", depth: "D" }] },
];

export const Route = createFileRoute("/mode/quiz")({
  head: () => ({ meta: [{ title: "Undertone Quiz · Tinta" }] }),
  component: Quiz,
});

function Quiz() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const { setCurrent } = useTinta();
  const navigate = useNavigate();
  const q = QUESTIONS[step];
  const selected = answers[step];

  const submit = () => {
    let w = 0, c = 0, n = 0;
    let depthScore = 0, depthCount = 0;
    answers.forEach((a, i) => {
      const opt = QUESTIONS[i].opts[a];
      if (opt.tag === "warm") w++;
      else if (opt.tag === "cool") c++;
      else n++;
      if (opt.depth) { depthCount++; depthScore += opt.depth === "L" ? 1 : opt.depth === "M" ? 2 : 3; }
    });
    const undertone = w > c && w > n ? "Warm" : c > w && c > n ? "Cool" : "Neutral";
    const avgDepth = depthCount ? depthScore / depthCount : 2;
    // synthesize skin RGB matching tone & depth
    const base = avgDepth < 1.5 ? 230 : avgDepth < 2.5 ? 180 : 110;
    const skin = undertone === "Warm"
      ? { r: base, g: base - 30, b: base - 60 }
      : undertone === "Cool"
        ? { r: base - 10, g: base - 10, b: base }
        : { r: base, g: base - 20, b: base - 30 };
    const result = analyze(skin);
    setCurrent(result);
    navigate({ to: "/results" });
  };

  return (
    <ModeShell title="Undertone Quiz" subtitle={`Question ${step + 1} of ${QUESTIONS.length}`}>
      <div className="flex gap-1.5 mb-6">
        {QUESTIONS.map((_, i) => (
          <div key={i} className={`h-1.5 flex-1 rounded-full transition-all ${i <= step ? "bg-primary" : "bg-muted"}`} />
        ))}
      </div>
      <h2 className="font-display text-2xl mb-5">{q.q}</h2>
      <div className="space-y-2">
        {q.opts.map((o, i) => (
          <button
            key={i}
            onClick={() => setAnswers((a) => { const n = [...a]; n[step] = i; return n; })}
            className={`w-full text-left px-4 py-3 rounded-xl border transition-all ${
              selected === i
                ? "border-primary bg-primary/10 text-primary font-semibold"
                : "border-border hover:border-primary/50"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>
      <div className="flex justify-between mt-8">
        <Button variant="outline" className="pill-btn" disabled={step === 0} onClick={() => setStep(step - 1)}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        {step < QUESTIONS.length - 1 ? (
          <Button className="pill-btn bg-primary text-primary-foreground hover:bg-primary/90"
            disabled={selected === undefined} onClick={() => setStep(step + 1)}>
            Next <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        ) : (
          <Button className="pill-btn bg-primary text-primary-foreground hover:bg-primary/90"
            disabled={selected === undefined} onClick={submit}>
            Reveal Season
          </Button>
        )}
      </div>
    </ModeShell>
  );
}
