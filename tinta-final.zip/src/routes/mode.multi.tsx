import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ModeShell, LoadingShimmer } from "@/components/tinta/ModeShell";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { analyze, sampleSkinFromImage, averageRgb, makeThumbnail, NoFaceError } from "@/lib/tinta/analysis";

import { useTinta } from "@/lib/tinta/store";
import { X, AlertCircle } from "lucide-react";
import { PhotoInput } from "@/components/tinta/PhotoInput";

export const Route = createFileRoute("/mode/multi")({
  head: () => ({ meta: [{ title: "Multi-Photo · Tinta" }] }),
  component: Multi,
});

interface Slot {
  file: File;
  preview: string;
}

function Multi() {
  const [slots, setSlots] = useState<Slot[]>([]);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const { setCurrent } = useTinta();
  const navigate = useNavigate();

  const add = (file: File, preview: string) => {
    setErr("");
    setSlots((prev) => [...prev, { file, preview }].slice(0, 6));
  };

  const run = async () => {
    if (slots.length < 2) {
      setErr("Please add at least 2 photos");
      return;
    }
    setLoading(true);
    setErr("");
    try {
      const skins = [];
      let rejected = 0;
      for (const s of slots) {
        try {
          skins.push(await sampleSkinFromImage(s.file));
        } catch (e) {
          if (e instanceof NoFaceError) rejected++;
        }
      }
      if (skins.length < 2) {
        throw new Error(
          rejected
            ? `${rejected} photo(s) had no detectable face. Please upload clear face photos.`
            : "Could not read enough photos.",
        );
      }
      const avg = averageRgb(skins);
      const result = analyze(avg);
      const thumb = await makeThumbnail(slots[0].file).catch(() => undefined);
      setCurrent(result, thumb ?? null);
      setTimeout(() => navigate({ to: "/results" }), 500);

    } catch (e) {
      setErr(e instanceof Error ? e.message : "Analysis failed.");
      setLoading(false);
    }
  };

  if (loading)
    return (
      <ModeShell title="Multi-Photo" subtitle="Detecting faces & averaging readings…">
        <LoadingShimmer label="Averaging readings…" />
      </ModeShell>
    );

  return (
    <ModeShell title="Multi-Photo" subtitle="Add 2 or more face photos for stronger accuracy.">
      <PhotoInput onPhoto={add} label={`Add photo (${slots.length}/6)`} compact />
      {slots.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-4">
          {slots.map((s, i) => (
            <div key={i} className="relative aspect-square rounded-lg overflow-hidden border border-border">
              <img src={s.preview} alt="" className="h-full w-full object-cover" />
              <button
                type="button"
                onClick={() => setSlots(slots.filter((_, j) => j !== i))}
                className="absolute top-1 right-1 bg-background/80 rounded-full p-0.5"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}
      {err && (
        <div className="mt-4 flex items-start gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          <AlertCircle className="h-4 w-4 mt-0.5" /> {err}
        </div>
      )}
      <Button
        onClick={run}
        disabled={slots.length < 2}
        className="w-full mt-6 pill-btn bg-primary text-primary-foreground hover:bg-primary/90"
      >
        Analyze {slots.length} Photos
      </Button>
    </ModeShell>
  );
}
