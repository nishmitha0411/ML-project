import { createFileRoute } from "@tanstack/react-router";
import { ModeShell, LoadingShimmer } from "@/components/tinta/ModeShell";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { analyze, sampleSkinFromImage, NoFaceError, type AnalysisResult } from "@/lib/tinta/analysis";
import { getSeason } from "@/lib/tinta/seasons";
import { AlertCircle } from "lucide-react";
import { PhotoInput } from "@/components/tinta/PhotoInput";

export const Route = createFileRoute("/mode/compare")({
  head: () => ({ meta: [{ title: "Compare Photos · Tinta" }] }),
  component: Compare,
});

interface Slot {
  file: File | null;
  preview: string | null;
  result: AnalysisResult | null;
}

function Compare() {
  const [a, setA] = useState<Slot>({ file: null, preview: null, result: null });
  const [b, setB] = useState<Slot>({ file: null, preview: null, result: null });
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const run = async () => {
    if (!a.file || !b.file) return;
    setLoading(true);
    setErr("");
    try {
      const [skinA, skinB] = await Promise.all([
        sampleSkinFromImage(a.file),
        sampleSkinFromImage(b.file),
      ]);
      setA((s) => ({ ...s, result: analyze(skinA) }));
      setB((s) => ({ ...s, result: analyze(skinB) }));
    } catch (e) {
      setErr(
        e instanceof NoFaceError
          ? e.message
          : e instanceof Error
            ? e.message
            : "Comparison failed.",
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <ModeShell title="Compare" subtitle="Two photos, independent results.">
        <LoadingShimmer label="Comparing photos…" />
      </ModeShell>
    );

  return (
    <ModeShell title="Compare Photos" subtitle="Two independent analyses, side by side — no data mixing.">
      <div className="grid sm:grid-cols-2 gap-4">
        {([
          ["A", a, setA] as const,
          ["B", b, setB] as const,
        ]).map(([label, slot, setSlot]) => (
          <div key={label}>
            <PhotoInput
              compact
              label={`Photo ${label}`}
              previewUrl={slot.preview}
              onPhoto={(file, preview) => setSlot({ file, preview, result: null })}
            />
            {slot.result && (
              <div className="mt-3 p-4 rounded-xl border border-border">
                <div className="text-2xl">{getSeason(slot.result.season).emoji}</div>
                <div className="font-display text-lg">{slot.result.season}</div>
                <div className="text-xs text-muted-foreground">
                  {slot.result.undertone} · {slot.result.depth} · {slot.result.confidence}%
                </div>
                <div className="flex gap-1 mt-2">
                  {getSeason(slot.result.season).palette.map((c) => (
                    <div key={c} className="h-4 flex-1 rounded" style={{ background: c }} />
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      {err && (
        <div className="mt-4 flex items-start gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          <AlertCircle className="h-4 w-4 mt-0.5" /> {err}
        </div>
      )}
      <Button
        onClick={run}
        disabled={!a.file || !b.file}
        className="w-full mt-6 pill-btn bg-primary text-primary-foreground hover:bg-primary/90"
      >
        Compare Both
      </Button>
    </ModeShell>
  );
}
