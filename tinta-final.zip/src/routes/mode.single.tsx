import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ModeShell, LoadingShimmer } from "@/components/tinta/ModeShell";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  analyze, sampleSkinFromImage, makeThumbnail,
  NoFaceError, MultipleFacesError,
} from "@/lib/tinta/analysis";
import { useTinta } from "@/lib/tinta/store";
import { AlertCircle } from "lucide-react";
import { PhotoInput } from "@/components/tinta/PhotoInput";
import { FacePicker } from "@/components/tinta/FacePicker";
import type { FaceBox } from "@/lib/tinta/faceDetect";

export const Route = createFileRoute("/mode/single")({
  head: () => ({
    meta: [
      { title: "Single Photo · Tinta" },
      { name: "description", content: "Upload one well-lit selfie for an instant 12-season color analysis. Processed entirely on your device." },
      { property: "og:title", content: "Single Photo · Tinta" },
      { property: "og:description", content: "Upload one well-lit selfie for an instant 12-season color analysis." },
    ],
  }),
  component: SinglePhoto,
});

interface PickerState {
  previewUrl: string;
  imgW: number;
  imgH: number;
  faces: FaceBox[];
}

function SinglePhoto() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [picker, setPicker] = useState<PickerState | null>(null);
  const { setCurrent } = useTinta();
  const navigate = useNavigate();

  const runAnalysis = async (chosenBox?: FaceBox) => {
    if (!file) return;
    setLoading(true); setErr("");
    try {
      const skin = await sampleSkinFromImage(file, {
        faceBox: chosenBox,
        detectMultiple: !chosenBox,
      });
      const result = analyze(skin);
      if (result.confidence < 55) {
        setErr("Low confidence — try a clearer, brighter photo of your face.");
        setLoading(false); return;
      }
      const thumb = await makeThumbnail(file).catch(() => undefined);
      setCurrent(result, thumb ?? null);
      setTimeout(() => navigate({ to: "/results" }), 600);
    } catch (e) {
      if (e instanceof MultipleFacesError) {
        setPicker({ previewUrl: e.previewUrl, imgW: e.imgW, imgH: e.imgH, faces: e.faces });
        setLoading(false);
        return;
      }
      setErr(
        e instanceof NoFaceError
          ? e.message
          : e instanceof Error ? e.message : "Could not analyze this photo."
      );
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <ModeShell title="Single Photo" subtitle="Detecting your face & sampling skin tone…">
        <LoadingShimmer />
      </ModeShell>
    );
  }

  return (
    <ModeShell
      title="Single Photo"
      subtitle="Take or upload one well-lit, makeup-free selfie facing natural light."
    >
      <PhotoInput
        previewUrl={preview}
        onPhoto={(f, url) => { setErr(""); setFile(f); setPreview(url); }}
      />
      {err && (
        <div className="mt-4 flex items-start gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          <AlertCircle className="h-4 w-4 mt-0.5" /> {err}
        </div>
      )}
      <Button
        onClick={() => runAnalysis()}
        disabled={!file}
        className="w-full mt-6 pill-btn bg-primary text-primary-foreground hover:bg-primary/90"
      >
        Analyze My Colors
      </Button>

      {picker && (
        <FacePicker
          previewUrl={picker.previewUrl}
          imgW={picker.imgW}
          imgH={picker.imgH}
          faces={picker.faces}
          onCancel={() => setPicker(null)}
          onPick={(box) => { setPicker(null); runAnalysis(box); }}
        />
      )}
    </ModeShell>
  );
}
