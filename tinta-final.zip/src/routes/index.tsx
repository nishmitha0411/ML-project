import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Palette, BookHeart } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tinta — AI Personal Color Atelier" },
      { name: "description", content: "Discover your 12-season color palette through six AI-guided analysis modes. Palette, makeup, wardrobe and more." },
      { property: "og:title", content: "Tinta — AI Personal Color Atelier" },
      { property: "og:description", content: "Your personal 12-season color analysis, beautifully crafted." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="relative overflow-hidden">
      {/* hero */}
      <section className="px-6 md:px-12 pt-16 pb-20 max-w-6xl mx-auto">
        <div className="fade-slide-in">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-primary font-semibold mb-6">
            <span className="h-px w-8 bg-primary" /> Personal Color · Est. 2026
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold leading-[1.05] text-secondary dark:text-foreground max-w-3xl">
            The colors you were <em className="text-primary not-italic">made</em> to wear.
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
            Tinta is an AI-guided color atelier. Six ways to discover your 12-season palette —
            curated makeup, wardrobe and jewelry, all in one quiet studio.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link
              to="/analyze"
              className="pill-btn bg-primary text-primary-foreground hover:bg-primary/90 inline-flex items-center gap-2 shadow-lg shadow-primary/20"
            >
              Begin Your Analysis <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/diary"
              className="pill-btn border border-border inline-flex items-center gap-2 hover:bg-muted/50"
            >
              <BookHeart className="h-4 w-4" /> Open Diary
            </Link>
          </div>
        </div>

        {/* palette strip */}
        <div className="mt-16 grid grid-cols-12 gap-1 h-24 rounded-2xl overflow-hidden shadow-xl fade-slide-in stagger-2">
          {["#F8D7C4", "#E9C46A", "#C8963C", "#B07A6E", "#9C0F3D", "#4A3728",
            "#1B4332", "#178582", "#6A8CAF", "#A8B8D8", "#E0BBE4", "#1A1816"].map((c) => (
              <div key={c} className="transition-transform hover:scale-y-110" style={{ background: c }} />
            ))}
        </div>

        {/* features */}
        <div className="mt-20 grid md:grid-cols-3 gap-6">
          {[
            { i: Palette, t: "12 Seasons", d: "Light Spring to Dark Winter — the complete classical system, refined." },
            { i: Sparkles, t: "Six Modes", d: "Single photo, multi-photo, manual picker, quiz, compare, calibrate." },
            { i: BookHeart, t: "Your Diary", d: "Save analyses to your private archive. Revisit, compare, evolve." },
          ].map(({ i: I, t, d }, idx) => (
            <div key={t} className={`p-6 rounded-2xl border border-border bg-card fade-slide-in stagger-${idx + 1}`}>
              <I className="h-6 w-6 text-primary mb-3" />
              <div className="font-display text-xl mb-1">{t}</div>
              <div className="text-sm text-muted-foreground">{d}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
