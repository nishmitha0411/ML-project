import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ModeShell } from "@/components/tinta/ModeShell";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { analyze, hexToRgb } from "@/lib/tinta/analysis";
import { useTinta } from "@/lib/tinta/store";

export const Route = createFileRoute("/mode/manual")({
  head: () => ({ meta: [{ title: "Manual Picker · Tinta" }] }),
  component: Manual,
});

function Manual() {
  const [skin, setSkin] = useState("#C99875");
  const [eye, setEye] = useState("#5C3A21");
  const [hair, setHair] = useState("#2E1A0F");
  const { setCurrent } = useTinta();
  const navigate = useNavigate();

  const run = () => {
    const result = analyze(hexToRgb(skin), hexToRgb(eye), hexToRgb(hair));
    setCurrent(result);
    navigate({ to: "/results" });
  };

  const pickers: [string, string, (v: string) => void][] = [
    ["Skin", skin, setSkin], ["Eye", eye, setEye], ["Hair", hair, setHair],
  ];

  return (
    <ModeShell title="Manual Picker" subtitle="Choose your skin, eye and hair colors. Live preview below.">
      <div className="grid sm:grid-cols-3 gap-4">
        {pickers.map(([label, val, set]) => (
          <div key={label} className="p-4 rounded-2xl border border-border">
            <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{label}</div>
            <div className="flex items-center gap-3">
              <input type="color" value={val} onChange={(e) => set(e.target.value)}
                className="h-14 w-14 rounded-lg border border-border cursor-pointer" />
              <div className="flex-1">
                <div className="h-14 rounded-lg shadow-inner border border-border" style={{ background: val }} />
              </div>
            </div>
            <div className="text-xs font-mono mt-2 text-center">{val.toUpperCase()}</div>
          </div>
        ))}
      </div>
      <Button onClick={run} className="w-full mt-6 pill-btn bg-primary text-primary-foreground hover:bg-primary/90">
        Reveal My Season
      </Button>
    </ModeShell>
  );
}
