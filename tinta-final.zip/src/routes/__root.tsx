import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/tinta/AppSidebar";
import { Toaster } from "@/components/ui/sonner";
import "@/lib/tinta/store";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#9C0F3D" },
      // Defense-in-depth CSP for a fully client-side app.
      {
        httpEquiv: "Content-Security-Policy",
        content:
          "default-src 'self'; " +
          "img-src 'self' data: blob:; " +
          "media-src 'self' blob:; " +
          "style-src 'self' 'unsafe-inline'; " +
          "font-src 'self' data:; " +
          "script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval'; " +
          "connect-src 'self' blob: data:; " +
          "worker-src 'self' blob:; " +
          "frame-ancestors 'self'; " +
          "base-uri 'self'; " +
          "form-action 'self'",
      },
      { name: "referrer", content: "strict-origin-when-cross-origin" },
      { title: "Tinta — AI Personal Color Atelier" },
      { name: "description", content: "Discover your 12-season color palette through six AI-guided modes. On-device face detection, no uploads." },
      { name: "author", content: "Tinta" },
      { property: "og:title", content: "Tinta — AI Personal Color Atelier" },
      { property: "og:description", content: "Discover your 12-season color palette through six AI-guided modes. On-device face detection, no uploads." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Tinta" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Tinta — AI Personal Color Atelier" },
      { name: "twitter:description", content: "Discover your 12-season color palette through six AI-guided modes. On-device face detection, no uploads." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/fb66559f-78e2-4644-96e9-1f2086ad14de" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/attachments/og-images/fb66559f-78e2-4644-96e9-1f2086ad14de" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", type: "image/png", sizes: "512x512", href: "/icon-512.png" },
      { rel: "apple-touch-icon", href: "/icon-512.png" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebApplication",
          name: "Tinta",
          applicationCategory: "LifestyleApplication",
          description: "On-device personal color analysis using the 12-season system.",
          operatingSystem: "Any (web)",
          offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});


function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-background">
          <AppSidebar />
          <div className="flex-1 flex flex-col min-w-0">
            <header className="h-14 flex items-center gap-3 border-b border-border px-4 bg-background/80 backdrop-blur sticky top-0 z-30">
              <SidebarTrigger />
              <span className="font-display text-lg text-secondary dark:text-foreground">Tinta</span>
              <span className="ml-auto text-xs text-muted-foreground hidden sm:block">
                AI Personal Color Atelier
              </span>
            </header>
            <main className="flex-1">
              <Outlet />
            </main>
          </div>
        </div>
        <Toaster />
      </SidebarProvider>
    </QueryClientProvider>
  );
}
