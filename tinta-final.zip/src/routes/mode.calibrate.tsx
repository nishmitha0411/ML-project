import { createFileRoute } from "@tanstack/react-router";
import { ModeShell, LoadingShimmer } from "@/components/tinta/ModeShell";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { calibrateFromWhite } from "@/lib/tinta/analysis";
import { sanitizePhoto } from "@/lib/tinta/fileSafety";
import { Upload, CheckCircle2, ShieldCheck, AlertCircle } from "lucide-react";

export const Route = createFileRoute("/mode/calibrate")({
  head: () => ({ meta: [{ title: "Calibrate Camera · Tinta" }] }),
  component: Calibrate,
});


function Calibrate() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [bias, setBias] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const onPick = async (f: File | undefined) => {
    setErr("");
    if (!f) return;
    try {
      const { file: clean, previewUrl } = await sanitizePhoto(f);
      setFile(clean);
      setPreview(previewUrl);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not read this photo.");
    }
  };

  const run = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const { bias } = await calibrateFromWhite(file);
      setBias(bias);
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <ModeShell title="Calibrate" subtitle="Reading your camera…">
        <LoadingShimmer label="Detecting camera bias…" />
      </ModeShell>
    );

  return (
    <ModeShell title="Calibrate Camera" subtitle="Upload a photo of a plain white surface in your usual lighting.">
      <label className="block border-2 border-dashed border-border rounded-2xl p-8 text-center cursor-pointer hover:border-primary transition">
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={(e) => onPick(e.target.files?.[0])}
        />
        {preview ? (
          <img src={preview} alt="" className="mx-auto rounded-xl max-h-48 object-cover" />
        ) : (
          <>
            <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <div className="text-sm font-semibold">Upload white reference</div>
          </>
        )}
      </label>
      {err && (
        <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          <AlertCircle className="h-4 w-4 mt-0.5" /> {err}
        </div>
      )}
      <p className="mt-3 flex items-start gap-1.5 text-xs text-muted-foreground">
        <ShieldCheck className="h-3.5 w-3.5 mt-0.5 text-primary shrink-0" />
        Processed on-device. The image is not uploaded anywhere.
      </p>
      {bias && (
        <div className="mt-5 p-4 rounded-xl bg-primary/10 border border-primary/30">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
            <div>
              <div className="font-semibold">Calibration complete</div>
              <div className="text-sm text-muted-foreground mt-1">{bias}</div>
              <div className="text-xs text-muted-foreground mt-2">
                We'll apply this offset to future photo-based analyses on this device.
              </div>
            </div>
          </div>
        </div>
      )}
      <Button onClick={run} disabled={!file}
        className="w-full mt-6 pill-btn bg-primary text-primary-foreground hover:bg-primary/90">
        Calibrate
      </Button>
    </ModeShell>
  );
}

