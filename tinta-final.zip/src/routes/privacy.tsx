import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, ScanFace, Server, Trash2, Cpu } from "lucide-react";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy · Tinta" },
      { name: "description", content: "How Tinta handles your photos: 100% on-device processing, no uploads, no tracking of image content." },
      { property: "og:title", content: "Privacy · Tinta" },
      { property: "og:description", content: "How Tinta handles your photos: 100% on-device processing, no uploads, no tracking." },
    ],
    links: [{ rel: "canonical", href: "/privacy" }],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <div className="max-w-2xl mx-auto px-6 md:px-10 py-12">
      <div className="mb-8 fade-slide-in">
        <div className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">Privacy</div>
        <h1 className="font-display text-4xl md:text-5xl text-secondary dark:text-foreground mt-2">
          Your photos stay on your device.
        </h1>
        <p className="text-muted-foreground mt-4">
          Tinta is built so that personal photos never leave the browser. This page explains
          exactly what happens when you use the app.
        </p>
      </div>

      <div className="space-y-6">
        <Section icon={Cpu} title="100% on-device processing">
          Face detection (BlazeFace) and skin-tone sampling run inside your browser using
          WebAssembly. Image bytes are never uploaded to a server, sent to a third party, or
          shared with us. We do not have an image API to receive them.
        </Section>

        <Section icon={ScanFace} title="Face-only analysis">
          Analysis only proceeds when a human face is detected with high confidence. Non-face
          photos (objects, landscapes, pets) are rejected before any sampling happens.
        </Section>

        <Section icon={Server} title="No analytics on photo content">
          We don't log, hash, or store any information derived from your image bytes. The only
          things saved are the results you explicitly add to your local Color Diary (season,
          undertone, palette, and an optional small thumbnail), and they live in your browser's
          local storage on your device.
        </Section>

        <Section icon={Trash2} title="Clear your data anytime">
          Your Color Diary is stored in browser local storage. You can delete individual entries
          from the Diary page, or clear your browser's site data to wipe everything.
        </Section>

        <Section icon={ShieldCheck} title="What we do collect">
          Standard web hosting logs (IP address, user agent, page URL) for security and
          uptime — never linked to photo content. No advertising trackers. No third-party
          analytics on photo bytes.
        </Section>
      </div>

      <div className="mt-10 p-5 rounded-2xl border border-primary/30 bg-primary/5">
        <p className="text-sm">
          Questions about privacy? <Link to="/" className="text-primary underline">Go back home</Link>.
        </p>
      </div>
    </div>
  );
}

function Section({
  icon: Icon, title, children,
}: { icon: typeof ShieldCheck; title: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-3 p-5 rounded-2xl border border-border bg-card">
      <Icon className="h-5 w-5 text-primary shrink-0 mt-0.5" />
      <div>
        <div className="font-display text-lg mb-1">{title}</div>
        <p className="text-sm text-muted-foreground leading-relaxed">{children}</p>
      </div>
    </div>
  );
}
