import { createFileRoute } from "@tanstack/react-router";
import { ResultsView } from "@/components/tinta/ResultsView";

export const Route = createFileRoute("/results")({
  head: () => ({
    meta: [
      { title: "Your Color Result · Tinta" },
      { name: "description", content: "Your personal 12-season color analysis result." },
    ],
  }),
  component: ResultsView,
});
