import { createFileRoute } from "@tanstack/react-router";
import { Camera, Images, Palette, ClipboardList, GitCompare, Sun, ShieldCheck } from "lucide-react";

import { ModeCard } from "@/components/tinta/ModeCard";

export const Route = createFileRoute("/analyze")({
  head: () => ({
    meta: [
      { title: "Choose your analysis · Tinta" },
      { name: "description", content: "Pick one of six ways to analyze your personal color season." },
    ],
  }),
  component: Analyze,
});

function Analyze() {
  return (
    <div className="max-w-5xl mx-auto px-6 md:px-10 py-10">
      <div className="mb-10 fade-slide-in">
        <div className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">Step One</div>
        <h1 className="font-display text-4xl md:text-5xl text-secondary dark:text-foreground mt-2">
          Choose your method
        </h1>
        <p className="text-muted-foreground mt-3 max-w-xl">
          Six different paths, one elegant result. Pick the mode that suits you — tap a card to begin.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ModeCard to="/mode/single" icon={Camera} title="Single Photo" delayClass="stagger-1"
          description="Upload one well-lit selfie. We sample your skin tone and classify your season." />
        <ModeCard to="/mode/multi" icon={Images} title="Multi-Photo" delayClass="stagger-2" accent="accent"
          description="Upload 2+ photos for greater accuracy. We average across lighting conditions." />
        <ModeCard to="/mode/manual" icon={Palette} title="Manual Picker" delayClass="stagger-3"
          description="Pick skin, eye and hair colors yourself. Ideal if you know your hex codes." />
        <ModeCard to="/mode/quiz" icon={ClipboardList} title="Undertone Quiz" delayClass="stagger-4" accent="accent"
          description="Six gentle questions — veins, metals, sun. The classic consultant method." />
        <ModeCard to="/mode/compare" icon={GitCompare} title="Compare Photos" delayClass="stagger-1" accent="accent"
          description="Two independent photos side-by-side. Useful for before/after lighting." />
        <ModeCard to="/mode/calibrate" icon={Sun} title="Calibrate Camera" delayClass="stagger-2"
          description="Upload a white-reference photo. We detect your camera's warm/cool bias." />
      </div>
    </div>
  );
}
