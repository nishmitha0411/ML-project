import { createFileRoute, Link } from "@tanstack/react-router";
import { useTinta, type DiaryEntry } from "@/lib/tinta/store";
import { getSeason } from "@/lib/tinta/seasons";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Trash2, BookHeart } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/diary")({
  head: () => ({
    meta: [
      { title: "Color Diary · Tinta" },
      { name: "description", content: "Your private archive of saved color analyses." },
    ],
  }),
  component: Diary,
});

function Diary() {
  const { diary, deleteEntry, setCurrent } = useTinta();
  const [sort, setSort] = useState<"new" | "old">("new");
  const [filter, setFilter] = useState<string>("All");

  const seasons: string[] = ["All", ...Array.from(new Set(diary.map((d: DiaryEntry) => d.result.season)))];
  let list = [...diary];
  if (filter !== "All") list = list.filter((d) => d.result.season === filter);
  list.sort((a, b) => sort === "new" ? b.createdAt - a.createdAt : a.createdAt - b.createdAt);

  return (
    <div className="max-w-5xl mx-auto px-6 md:px-10 py-10">
      <div className="flex items-center justify-between flex-wrap gap-4 mb-8 fade-slide-in">
        <div>
          <div className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">Archive</div>
          <h1 className="font-display text-4xl text-secondary dark:text-foreground mt-1">Color Diary</h1>
        </div>
        <div className="flex gap-2">
          <select value={filter} onChange={(e) => setFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-border bg-background text-sm">
            {seasons.map((s) => <option key={s}>{s}</option>)}
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value as any)}
            className="px-3 py-2 rounded-lg border border-border bg-background text-sm">
            <option value="new">Newest first</option>
            <option value="old">Oldest first</option>
          </select>
        </div>
      </div>

      {list.length === 0 ? (
        <div className="text-center py-20 border border-dashed border-border rounded-2xl">
          <BookHeart className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground mb-4">Your diary is empty.</p>
          <Button asChild className="pill-btn bg-primary text-primary-foreground hover:bg-primary/90">
            <Link to="/analyze">Start your first analysis</Link>
          </Button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((e, idx) => {
            const s = getSeason(e.result.season);
            return (
              <div key={e.id} className={`neomorph rounded-2xl p-5 fade-slide-in stagger-${(idx % 4) + 1}`}>
                <div className="flex items-start justify-between mb-3 gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    {e.thumbnail && (
                      <img
                        src={e.thumbnail}
                        alt=""
                        className="h-14 w-14 rounded-xl object-cover ring-1 ring-border shrink-0"
                      />
                    )}
                    <div className="min-w-0">
                      <div className="text-2xl">{s.emoji}</div>
                      <div className="font-display text-lg mt-1 truncate">{e.result.season}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(e.createdAt).toLocaleDateString()} · {e.result.confidence}% match
                      </div>
                    </div>
                  </div>
                  <AlertDialog>

                    <AlertDialogTrigger asChild>
                      <button className="p-1.5 rounded-lg hover:bg-destructive/10 hover:text-destructive transition">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete this entry?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This {e.result.season} analysis will be permanently removed from your diary.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => deleteEntry(e.id)}>Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                <div className="flex gap-1 mb-3">
                  {s.palette.map((c) => <div key={c} className="h-6 flex-1 rounded" style={{ background: c }} />)}
                </div>
                <Button
                  variant="outline" size="sm" className="w-full pill-btn"
                  asChild
                  onClick={() => setCurrent(e.result)}
                >
                  <Link to="/results">View Result</Link>
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
